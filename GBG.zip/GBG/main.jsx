// GBG Smart Village 3D Digital Twin
// Core runtime initialized in script.js and index.html
export {};
