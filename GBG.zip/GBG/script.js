/**
 * =====================================================================
 * GBG VILLAGE 3D DIGITAL TWIN & 180-RESIDENT SOCIAL DIRECTORY
 * Three.js WebGL Engine, Pin-to-Pin Zooming, Youth Leader Thiru Hero
 * =====================================================================
 */

(function () {
  'use strict';

  // --- Global State ---
  const state = {
    currentLandmark: 'overview',
    isNight: false,
    timeOfDay: 'day', // 'day', 'sunset', 'night'
    labelsVisible: true,
    satelliteTextureEnabled: true,
    audioPlaying: false,
    audioCtx: null,
    censusFilter: 'all',
    censusSearchQuery: '',
    censusViewMode: 'cards', // 'cards' | 'table'
    isTouring: false,
    tourIndex: 0
  };

  // --- Three.js Variables ---
  let scene, camera, renderer, controls;
  let groundMesh, roadGroup, buildingGroup, foliageGroup, pinGroup, lightsGroup;
  let flagMeshes = [];
  let raycaster, mouse;
  let interactiveObjects = [];
  let animFrameId = null;

  // Camera animation target
  const cameraAnim = {
    active: false,
    startPos: new THREE.Vector3(),
    targetPos: new THREE.Vector3(),
    startLook: new THREE.Vector3(),
    targetLook: new THREE.Vector3(),
    currentLook: new THREE.Vector3(),
    progress: 0,
    duration: 1.6,
    startTime: 0,
    onComplete: null
  };

  // --- DOM Elements ---
  const dom = {
    container: document.getElementById('canvas-container'),
    navPills: document.querySelectorAll('.nav-pill'),
    btnHero: document.getElementById('btn-hero-showcase'),
    btnCensus: document.getElementById('btn-open-census'),
    heroModal: document.getElementById('hero-modal'),
    btnCloseHero: document.getElementById('btn-close-hero'),
    btnFlyThiru: document.getElementById('btn-fly-thiru-house'),
    censusModal: document.getElementById('census-modal'),
    btnCloseCensus: document.getElementById('btn-close-census'),
    censusContainer: document.getElementById('census-results-container'),
    searchInput: document.getElementById('census-search-input'),
    btnClearSearch: document.getElementById('btn-clear-search'),
    filterChips: document.querySelectorAll('.filter-chip'),
    resultsCount: document.getElementById('results-count-text'),
    btnViewCards: document.getElementById('btn-view-cards'),
    btnViewTable: document.getElementById('btn-view-table'),
    personModal: document.getElementById('person-modal'),
    personModalContent: document.getElementById('person-modal-content'),
    btnClosePerson: document.getElementById('btn-close-person'),
    landmarkDrawer: document.getElementById('landmark-drawer'),
    btnCloseDrawer: document.getElementById('btn-close-drawer'),
    drawerIcon: document.getElementById('drawer-icon'),
    drawerCategory: document.getElementById('drawer-category'),
    drawerTitle: document.getElementById('drawer-title'),
    drawerSubtitle: document.getElementById('drawer-subtitle'),
    drawerDesc: document.getElementById('drawer-description'),
    drawerMeta: document.getElementById('drawer-meta-grid'),
    drawerFeatures: document.getElementById('drawer-features'),
    drawerBtnResidents: document.getElementById('drawer-btn-residents'),
    btnSound: document.getElementById('btn-sound-toggle'),
    todButtons: document.querySelectorAll('.tod-btn'),
    btnCinematicTour: document.getElementById('btn-cinematic-tour'),
    btnResetCam: document.getElementById('btn-reset-cam'),
    btnToggleLabels: document.getElementById('btn-toggle-labels'),
    btnToggleTexture: document.getElementById('btn-toggle-texture'),
    btnTakePhoto: document.getElementById('btn-take-photo'),
    toast: document.getElementById('toast'),
    toastMessage: document.getElementById('toast-message'),
    btnExportCsv: document.getElementById('btn-export-csv'),
    btnExportJson: document.getElementById('btn-export-json')
  };

  // --- Initialise Application ---
  function init() {
    initThree();
    buildWorld();
    setupEvents();
    renderCensusList();
    animate(0);
    showToast('✨ Welcome to GBG Village 3D! Click any pin to zoom.');
  }

  // --- WebGL Three.js Scene Setup ---
  function initThree() {
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x87ceeb); // Day sky blue
    scene.fog = new THREE.FogExp2(0x87ceeb, 0.005);

    const aspect = window.innerWidth / window.innerHeight;
    camera = new THREE.PerspectiveCamera(45, aspect, 0.5, 1000);
    camera.position.set(0, 85, 95);
    cameraAnim.currentLook.set(-5, 0, 5);
    camera.lookAt(cameraAnim.currentLook);

    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, preserveDrawingBuffer: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;

    dom.container.appendChild(renderer.domElement);

    // OrbitControls
    if (typeof THREE.OrbitControls !== 'undefined') {
      controls = new THREE.OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;
      controls.dampingFactor = 0.05;
      controls.maxPolarAngle = Math.PI / 2.1; // Don't go below ground
      controls.minDistance = 6;
      controls.maxDistance = 220;
      controls.target.copy(cameraAnim.currentLook);
    }

    raycaster = new THREE.Raycaster();
    mouse = new THREE.Vector2();

    // Groups
    roadGroup = new THREE.Group();
    buildingGroup = new THREE.Group();
    foliageGroup = new THREE.Group();
    pinGroup = new THREE.Group();
    lightsGroup = new THREE.Group();

    scene.add(roadGroup);
    scene.add(buildingGroup);
    scene.add(foliageGroup);
    scene.add(pinGroup);
    scene.add(lightsGroup);

    setupLighting();
  }

  // --- Lighting & Ambiance Setup ---
  let hemiLight, dirLight, ambientLight, templeLight, thiruGlowLight;

  function setupLighting() {
    ambientLight = new THREE.AmbientLight(0xffffff, 0.45);
    lightsGroup.add(ambientLight);

    hemiLight = new THREE.HemisphereLight(0xffffff, 0x3d5c2e, 0.5);
    lightsGroup.add(hemiLight);

    dirLight = new THREE.DirectionalLight(0xfff4d6, 1.2);
    dirLight.position.set(60, 100, 40);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    dirLight.shadow.camera.near = 10;
    dirLight.shadow.camera.far = 300;
    const d = 90;
    dirLight.shadow.camera.left = -d;
    dirLight.shadow.camera.right = d;
    dirLight.shadow.camera.top = d;
    dirLight.shadow.camera.bottom = -d;
    dirLight.shadow.bias = -0.0005;
    lightsGroup.add(dirLight);

    // Temple Aarti Diya warm sanctum glow
    templeLight = new THREE.PointLight(0xff7700, 2.5, 25);
    templeLight.position.set(-18, 3.5, 14);
    lightsGroup.add(templeLight);

    // Thiru's House Leader warm amber glow
    thiruGlowLight = new THREE.PointLight(0xf59e0b, 1.8, 30);
    thiruGlowLight.position.set(15, 4.5, 23);
    lightsGroup.add(thiruGlowLight);
  }

  // --- World Generation: Terrain, Roads, 3D Buildings ---
  function buildWorld() {
    buildTerrain();
    buildRoads();
    buildHanumanTemple();
    buildThiruHouse();
    buildSchool();
    buildPanchayatCenter();
    buildVillageHouses();
    buildAgriculturalFields();
    buildFoliage();
    buildFloating3DPins();
  }

  // 1. Terrain Mesh with Satellite Texture Mapping
  function buildTerrain() {
    const terrainGeo = new THREE.PlaneGeometry(240, 200, 64, 64);
    terrainGeo.rotateX(-Math.PI / 2);

    // Add gentle elevation hills in background and subtle field contours
    const pos = terrainGeo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      let y = 0;

      // North & West Hills
      if (z < -40) {
        y += Math.sin(x * 0.05) * 4 + (Math.abs(z + 40) * 0.12);
      }
      if (x < -60) {
        y += (Math.abs(x + 60) * 0.15);
      }
      // Stepped agricultural terrace slope in South East
      if (z > 20 && x > 5) {
        y += Math.floor((z + x) / 14) * 0.6;
      }
      pos.setY(i, y);
    }
    terrainGeo.computeVertexNormals();

    // Satellite texture loader with Canvas fallback
    let groundTexture;
    if (window.SATELLITE_BASE64) {
      const img = new Image();
      img.src = window.SATELLITE_BASE64;
      groundTexture = new THREE.Texture(img);
      img.onload = function () {
        groundTexture.needsUpdate = true;
      };
    } else {
      groundTexture = createProceduralVillageTexture();
    }

    groundTexture.wrapS = THREE.ClampToEdgeWrapping;
    groundTexture.wrapT = THREE.ClampToEdgeWrapping;

    const groundMat = new THREE.MeshStandardMaterial({
      map: groundTexture,
      roughness: 0.85,
      metalness: 0.05
    });

    groundMesh = new THREE.Mesh(terrainGeo, groundMat);
    groundMesh.receiveShadow = true;
    scene.add(groundMesh);
  }

  // Fallback high-res procedural texture if image loading fails
  function createProceduralVillageTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d');

    // Base rural green & dry earth
    ctx.fillStyle = '#4a5d3f';
    ctx.fillRect(0, 0, 1024, 1024);

    // Terraced fields (yellowish green and ochre)
    ctx.fillStyle = '#5c7345';
    for (let i = 0; i < 15; i++) {
      ctx.fillRect(500 + (i * 25), 450 + (i * 30), 200, 40);
    }

    // Diagonal main road
    ctx.strokeStyle = '#6d7570';
    ctx.lineWidth = 26;
    ctx.beginPath();
    ctx.moveTo(100, 50);
    ctx.lineTo(950, 650);
    ctx.stroke();

    return new THREE.CanvasTexture(canvas);
  }

  // 2. Rural Asphalt Roads & Connecting Paths
  function buildRoads() {
    const roadMat = new THREE.MeshStandardMaterial({ color: 0x474b4e, roughness: 0.9 });
    const shoulderMat = new THREE.MeshStandardMaterial({ color: 0xb58c5a, roughness: 1.0 });

    // Main Diagonal Highway (matching satellite photo)
    const mainRoadGeo = new THREE.PlaneGeometry(16, 230);
    mainRoadGeo.rotateX(-Math.PI / 2);
    const mainRoad = new THREE.Mesh(mainRoadGeo, roadMat);
    mainRoad.position.set(0, 0.08, 0);
    mainRoad.rotation.y = -Math.PI / 4.8;
    mainRoad.receiveShadow = true;
    roadGroup.add(mainRoad);

    // Road shoulder / red earth gravel verge
    const shoulderGeo = new THREE.PlaneGeometry(22, 230);
    shoulderGeo.rotateX(-Math.PI / 2);
    const shoulder = new THREE.Mesh(shoulderGeo, shoulderMat);
    shoulder.position.set(0, 0.05, 0);
    shoulder.rotation.y = -Math.PI / 4.8;
    shoulder.receiveShadow = true;
    roadGroup.add(shoulder);

    // Branch road to Thiru's House & East Hamlet
    const branchGeo = new THREE.PlaneGeometry(8, 65);
    branchGeo.rotateX(-Math.PI / 2);
    const branchRoad = new THREE.Mesh(branchGeo, roadMat);
    branchRoad.position.set(10, 0.1, 10);
    branchRoad.rotation.y = Math.PI / 8;
    branchRoad.receiveShadow = true;
    roadGroup.add(branchRoad);

    // Branch road to Hanuman Temple
    const templeRoadGeo = new THREE.PlaneGeometry(7, 35);
    templeRoadGeo.rotateX(-Math.PI / 2);
    const templeRoad = new THREE.Mesh(templeRoadGeo, roadMat);
    templeRoad.position.set(-14, 0.1, 8);
    templeRoad.rotation.y = -Math.PI / 3;
    templeRoad.receiveShadow = true;
    roadGroup.add(templeRoad);
  }

  // 3. SRI HANUMAN TEMPLE (ஆஞ்சநேயர் கோயில்) - 3D Architectural Model
  function buildHanumanTemple() {
    const templeGroup = new THREE.Group();
    templeGroup.position.set(-18, 0, 14);

    // Materials
    const stonePlinthMat = new THREE.MeshStandardMaterial({ color: 0xa8a29e, roughness: 0.8 });
    const templeWallMat = new THREE.MeshStandardMaterial({ color: 0xfef08a, roughness: 0.6 }); // Ochre yellow temple
    const gopuramMat = new THREE.MeshStandardMaterial({ color: 0xf97316, roughness: 0.5 }); // Saffron orange
    const goldMat = new THREE.MeshStandardMaterial({ color: 0xfbbf24, metalness: 0.85, roughness: 0.2 });
    const pillarMat = new THREE.MeshStandardMaterial({ color: 0xd6d3d1, roughness: 0.7 });

    // 1. Raised Stone Base / Plinth
    const plinthGeo = new THREE.BoxGeometry(14, 1.2, 18);
    const plinth = new THREE.Mesh(plinthGeo, stonePlinthMat);
    plinth.position.y = 0.6;
    plinth.castShadow = true;
    plinth.receiveShadow = true;
    templeGroup.add(plinth);

    // Steps leading to temple
    const stepsGeo = new THREE.BoxGeometry(6, 0.6, 3);
    const steps = new THREE.Mesh(stepsGeo, stonePlinthMat);
    steps.position.set(0, 0.3, 10);
    templeGroup.add(steps);

    // 2. Sanctum Sanctorum (Garbhagriha)
    const sanctumGeo = new THREE.BoxGeometry(8, 5, 8);
    const sanctum = new THREE.Mesh(sanctumGeo, templeWallMat);
    sanctum.position.set(0, 3.7, -4);
    sanctum.castShadow = true;
    sanctum.receiveShadow = true;
    templeGroup.add(sanctum);

    // 3. Pyramidal Vimana / Gopuram Tower over Sanctum
    const vimanaLevels = 4;
    for (let i = 0; i < vimanaLevels; i++) {
      const size = 7 - (i * 1.4);
      const levelGeo = new THREE.BoxGeometry(size, 1.2, size);
      const level = new THREE.Mesh(levelGeo, gopuramMat);
      level.position.set(0, 6.8 + (i * 1.2), -4);
      level.castShadow = true;
      templeGroup.add(level);
    }

    // 4. Golden Kalash (Spire / Finial)
    const kalashGeo = new THREE.ConeGeometry(0.7, 2, 8);
    const kalash = new THREE.Mesh(kalashGeo, goldMat);
    kalash.position.set(0, 12.2, -4);
    kalash.castShadow = true;
    templeGroup.add(kalash);

    // 5. Open Mandapam with Pillars
    const mandapRoofGeo = new THREE.BoxGeometry(11, 0.8, 10);
    const mandapRoof = new THREE.Mesh(mandapRoofGeo, templeWallMat);
    mandapRoof.position.set(0, 4.8, 4);
    mandapRoof.castShadow = true;
    templeGroup.add(mandapRoof);

    // Pillars
    const pillarGeo = new THREE.CylinderGeometry(0.3, 0.35, 3.6, 8);
    const pillarPositions = [
      [-4.5, 4], [4.5, 4], [-4.5, 8], [4.5, 8],
      [-1.8, 8], [1.8, 8], [-4.5, 0], [4.5, 0]
    ];
    pillarPositions.forEach(p => {
      const pillar = new THREE.Mesh(pillarGeo, pillarMat);
      pillar.position.set(p[0], 3.0, p[1]);
      pillar.castShadow = true;
      templeGroup.add(pillar);
    });

    // 6. Saffron Triangle Hanuman Dhwaja Flag on Mast
    const mastGeo = new THREE.CylinderGeometry(0.08, 0.08, 7, 8);
    const mast = new THREE.Mesh(mastGeo, goldMat);
    mast.position.set(3.5, 6.5, -4);
    templeGroup.add(mast);

    const flagGeo = new THREE.BufferGeometry();
    const flagVertices = new Float32Array([
      0, 0, 0,
      1.8, -0.4, 0,
      0, -1.0, 0
    ]);
    flagGeo.setAttribute('position', new THREE.BufferAttribute(flagVertices, 3));
    const flagMat = new THREE.MeshBasicMaterial({ color: 0xff6600, side: THREE.DoubleSide });
    const flagMesh = new THREE.Mesh(flagGeo, flagMat);
    flagMesh.position.set(3.5, 9.8, -4);
    templeGroup.add(flagMesh);
    flagMeshes.push(flagMesh);

    // 7. Temple Bell at Entrance
    const bellGeo = new THREE.ConeGeometry(0.3, 0.5, 8);
    bellGeo.rotateX(Math.PI);
    const bell = new THREE.Mesh(bellGeo, goldMat);
    bell.position.set(0, 4.2, 7.8);
    templeGroup.add(bell);

    // 8. Sacred Peepal Tree with Stone Circular Chabutra
    const chabutraGeo = new THREE.CylinderGeometry(4.5, 4.8, 1, 16);
    const chabutra = new THREE.Mesh(chabutraGeo, stonePlinthMat);
    chabutra.position.set(-11, 0.5, 12);
    chabutra.castShadow = true;
    templeGroup.add(chabutra);

    const tree = createLargePeepalTree();
    tree.position.set(-11, 1, 12);
    templeGroup.add(tree);

    // Mark as interactive
    templeGroup.userData = { id: 'temple', name: 'Sri Hanuman Temple', type: 'landmark' };
    interactiveObjects.push(sanctum, mandapRoof, plinth);
    sanctum.userData = templeGroup.userData;
    mandapRoof.userData = templeGroup.userData;
    plinth.userData = templeGroup.userData;

    buildingGroup.add(templeGroup);
  }

  // 4. YOUTH LEADER THIRU'S HOUSE & RESIDENCE (H-201)
  function buildThiruHouse() {
    const thiruGroup = new THREE.Group();
    thiruGroup.position.set(15, 0, 23);

    // Materials
    const wallMat = new THREE.MeshStandardMaterial({ color: 0xfef9c3, roughness: 0.6 }); // Cream yellow villa
    const roofMat = new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.5 }); // Terracotta tile roof
    const solarMat = new THREE.MeshStandardMaterial({ color: 0x1e3a8a, metalness: 0.8, roughness: 0.2 }); // Blue Solar Panel
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.7 });
    const goldBadgeMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.9, roughness: 0.2 });

    // Compound Wall with Gate
    const compoundGeo = new THREE.BoxGeometry(22, 1.2, 24);
    const compoundWall = new THREE.Mesh(compoundGeo, new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.9, wireframe: false }));
    // We create front lawn and house base
    const lawnGeo = new THREE.BoxGeometry(20, 0.4, 22);
    const lawn = new THREE.Mesh(lawnGeo, new THREE.MeshStandardMaterial({ color: 0x4d7c0f, roughness: 0.9 }));
    lawn.position.y = 0.2;
    lawn.receiveShadow = true;
    thiruGroup.add(lawn);

    // Main 2-Story Modern Rural House
    // Ground floor
    const gfGeo = new THREE.BoxGeometry(11, 3.8, 9);
    const gf = new THREE.Mesh(gfGeo, wallMat);
    gf.position.set(0, 2.1, 0);
    gf.castShadow = true;
    gf.receiveShadow = true;
    thiruGroup.add(gf);

    // First Floor
    const ffGeo = new THREE.BoxGeometry(8.5, 3.4, 7);
    const ff = new THREE.Mesh(ffGeo, wallMat);
    ff.position.set(0, 5.7, 0);
    ff.castShadow = true;
    thiruGroup.add(ff);

    // Front Veranda / Portico (Youth Assembly Center)
    const porticoGeo = new THREE.BoxGeometry(9, 0.4, 4);
    const portico = new THREE.Mesh(porticoGeo, roofMat);
    portico.position.set(0, 3.4, 6);
    thiruGroup.add(portico);

    // Portico pillars
    for (let x = -3.8; x <= 3.8; x += 7.6) {
      const p = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.25, 3.2, 8), woodMat);
      p.position.set(x, 1.8, 7.5);
      p.castShadow = true;
      thiruGroup.add(p);
    }

    // Sloped Hip Roof on Top
    const roofGeo = new THREE.ConeGeometry(7, 2.5, 4);
    roofGeo.rotateY(Math.PI / 4);
    const roof = new THREE.Mesh(roofGeo, roofMat);
    roof.position.set(0, 8.6, 0);
    roof.castShadow = true;
    thiruGroup.add(roof);

    // Rooftop Solar Panel Arrays (Highlighting Thiru's Solar Initiative!)
    for (let s = -2; s <= 2; s += 2) {
      const panel = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.1, 2.2), solarMat);
      panel.position.set(s, 7.5, 2.5);
      panel.rotation.x = -Math.PI / 6;
      thiruGroup.add(panel);
    }

    // Parked Farm Tractor / Utility Vehicle outside
    const tractor = createTractor();
    tractor.position.set(-6.5, 0.4, 7);
    thiruGroup.add(tractor);

    // Welcome Arch / Banner "THIRU ILLAM - YOUTH LEADER"
    const archBar = new THREE.Mesh(new THREE.BoxGeometry(6, 0.8, 0.3), goldBadgeMat);
    archBar.position.set(0, 4.2, 10.5);
    thiruGroup.add(archBar);

    // Coconut Palms in Thiru's courtyard
    const palm1 = createCoconutPalm();
    palm1.position.set(7.5, 0.4, -6);
    thiruGroup.add(palm1);

    const palm2 = createCoconutPalm();
    palm2.position.set(-7.5, 0.4, -6);
    thiruGroup.add(palm2);

    // Floating pulsing Golden Crown marker above house
    const crownGeo = new THREE.OctahedronGeometry(1.2, 0);
    const crown = new THREE.Mesh(crownGeo, goldBadgeMat);
    crown.position.set(0, 11.5, 0);
    thiruGroup.add(crown);
    thiruGroup.userData.crownMesh = crown;

    // Interactive setup
    thiruGroup.userData = { id: 'thiru_house', name: "Youth Leader Thiru's Residence", type: 'landmark' };
    gf.userData = thiruGroup.userData;
    ff.userData = thiruGroup.userData;
    roof.userData = thiruGroup.userData;
    interactiveObjects.push(gf, ff, roof);

    buildingGroup.add(thiruGroup);
  }

  // 5. GOVT PRIMARY & HIGH SCHOOL (CENTER VILLAGE)
  function buildSchool() {
    const schoolGroup = new THREE.Group();
    schoolGroup.position.set(-3, 0, -9);

    const schoolWallMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, roughness: 0.6 });
    const blueTileMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.5 });
    const tricolorMat = new THREE.MeshBasicMaterial({ color: 0xff9933 });

    // Main classroom block (L-shape)
    const block1 = new THREE.Mesh(new THREE.BoxGeometry(18, 4.2, 7), schoolWallMat);
    block1.position.set(0, 2.1, 0);
    block1.castShadow = true;
    schoolGroup.add(block1);

    const roof1 = new THREE.Mesh(new THREE.ConeGeometry(12, 2.2, 4), blueTileMat);
    roof1.rotateY(Math.PI / 4);
    roof1.scale.set(1.6, 1, 0.7);
    roof1.position.set(0, 5.3, 0);
    schoolGroup.add(roof1);

    // School wing
    const block2 = new THREE.Mesh(new THREE.BoxGeometry(6, 4.2, 12), schoolWallMat);
    block2.position.set(-8, 2.1, 5);
    block2.castShadow = true;
    schoolGroup.add(block2);

    // Open Assembly Ground / Playground
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(24, 20), new THREE.MeshStandardMaterial({ color: 0xc2a679, roughness: 1.0 }));
    ground.rotateX(-Math.PI / 2);
    ground.position.set(4, 0.15, 6);
    schoolGroup.add(ground);

    // Flag Mast with Indian Tricolor
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, 8, 8), new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: 0.8 }));
    mast.position.set(3, 4, 3);
    schoolGroup.add(mast);

    const flag = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 1.0), tricolorMat);
    flag.position.set(3.8, 7.2, 3);
    schoolGroup.add(flag);
    flagMeshes.push(flag);

    // Interactive setup
    schoolGroup.userData = { id: 'school', name: 'Govt. Village School', type: 'landmark' };
    block1.userData = schoolGroup.userData;
    block2.userData = schoolGroup.userData;
    interactiveObjects.push(block1, block2);

    buildingGroup.add(schoolGroup);
  }

  // 6. PANCHAYAT BHAVAN & OVERHEAD WATER TANK TOWER
  function buildPanchayatCenter() {
    const panchayatGroup = new THREE.Group();
    panchayatGroup.position.set(-5, 0, -6);

    const wallMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.6 });
    const roofMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.7 });

    // Panchayat Bhavan building
    const hall = new THREE.Mesh(new THREE.BoxGeometry(12, 4.5, 8), wallMat);
    hall.position.set(0, 2.25, 0);
    hall.castShadow = true;
    panchayatGroup.add(hall);

    // Pillars & Porch
    const porch = new THREE.Mesh(new THREE.BoxGeometry(6, 0.4, 3), roofMat);
    porch.position.set(0, 3.8, 5.5);
    panchayatGroup.add(porch);

    // Overhead Village Water Tower (Concrete Legs & Blue Tank)
    const tankGroup = new THREE.Group();
    tankGroup.position.set(12, 0, -2);

    // 4 Concrete pillars
    const legMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.9 });
    const legGeo = new THREE.CylinderGeometry(0.3, 0.35, 14, 8);
    [[-2, -2], [2, -2], [-2, 2], [2, 2]].forEach(pos => {
      const leg = new THREE.Mesh(legGeo, legMat);
      leg.position.set(pos[0], 7, pos[1]);
      leg.castShadow = true;
      tankGroup.add(leg);
    });

    // Circular Water Reservoir
    const tankGeo = new THREE.CylinderGeometry(4.2, 4.2, 5, 24);
    const tankMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.4 });
    const tank = new THREE.Mesh(tankGeo, tankMat);
    tank.position.y = 15.5;
    tank.castShadow = true;
    tankGroup.add(tank);

    panchayatGroup.add(tankGroup);

    // Interactive setup
    panchayatGroup.userData = { id: 'panchayat', name: 'Gram Panchayat & Community Hall', type: 'landmark' };
    hall.userData = panchayatGroup.userData;
    tank.userData = panchayatGroup.userData;
    interactiveObjects.push(hall, tank);

    buildingGroup.add(panchayatGroup);
  }

  // 7. VILLAGE HOUSES (38 Authentic Village Homes matching the 4 Wards)
  function buildVillageHouses() {
    if (!window.VILLAGE_DATA || !window.VILLAGE_DATA.houses) return;

    const wallColors = [0xfef08a, 0xffedd5, 0xf1f5f9, 0xe2e8f0, 0xfef9c3];
    const roofColors = [0xb45309, 0xc2410c, 0x9a3412, 0x78350f];

    window.VILLAGE_DATA.houses.forEach((house, idx) => {
      // Skip Thiru's house since it was custom built above
      if (house.houseNo.includes('H-201')) return;

      const houseGroup = new THREE.Group();
      houseGroup.position.set(house.x, 0, house.z);

      const wallColor = wallColors[idx % wallColors.length];
      const roofColor = roofColors[idx % roofColors.length];

      const wallMat = new THREE.MeshStandardMaterial({ color: wallColor, roughness: 0.7 });
      const roofMat = new THREE.MeshStandardMaterial({ color: roofColor, roughness: 0.6 });

      // Varied house footprints
      const w = 5.5 + ((idx % 3) * 0.8);
      const h = 2.8 + ((idx % 2) * 0.6);
      const d = 5.0 + ((idx % 2) * 0.7);

      const body = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), wallMat);
      body.position.y = h / 2;
      body.castShadow = true;
      body.receiveShadow = true;
      houseGroup.add(body);

      // Gabled Roof
      const roofGeo = new THREE.ConeGeometry(Math.max(w, d) * 0.75, 1.8, 4);
      roofGeo.rotateY(Math.PI / 4);
      const roof = new THREE.Mesh(roofGeo, roofMat);
      roof.position.y = h + 0.9;
      roof.castShadow = true;
      houseGroup.add(roof);

      // Veranda / Porch
      const porchGeo = new THREE.BoxGeometry(w * 0.7, 0.2, 1.8);
      const porch = new THREE.Mesh(porchGeo, roofMat);
      porch.position.set(0, 1.9, d / 2 + 0.9);
      houseGroup.add(porch);

      // Tree near house
      if (idx % 2 === 0) {
        const tree = createSmallVillageTree();
        tree.position.set(w / 2 + 2, 0, 0);
        houseGroup.add(tree);
      }

      // Metadata for raycasting
      const houseMeta = {
        id: 'house_' + house.houseNo,
        name: house.name,
        houseNo: house.houseNo,
        wardId: house.wardId,
        residents: house.residents,
        type: 'house',
        coordinates: [house.x, 0.5, house.z]
      };
      houseGroup.userData = houseMeta;
      body.userData = houseMeta;
      roof.userData = houseMeta;
      interactiveObjects.push(body, roof);

      buildingGroup.add(houseGroup);
    });
  }

  // 8. Agricultural Stepped Terraces & Fields
  function buildAgriculturalFields() {
    const fieldGroup = new THREE.Group();
    fieldGroup.position.set(24, 0.1, 10);

    const crops = [
      { color: 0x84cc16, rows: 6, label: 'Paddy Field (Organic)' },
      { color: 0xeab308, rows: 5, label: 'Millet & Mustard Plot' },
      { color: 0x22c55e, rows: 7, label: 'Sugarcane Plantation' },
      { color: 0xa3e635, rows: 4, label: 'Vegetable & Horticulture' }
    ];

    crops.forEach((crop, i) => {
      const plotGeo = new THREE.PlaneGeometry(28, 12);
      plotGeo.rotateX(-Math.PI / 2);
      const plotMat = new THREE.MeshStandardMaterial({ color: crop.color, roughness: 0.95 });
      const plot = new THREE.Mesh(plotGeo, plotMat);
      plot.position.set(0, 0.05 + (i * 0.4), i * 15);
      plot.receiveShadow = true;
      fieldGroup.add(plot);

      // Crop row ridges
      for (let r = -5; r <= 5; r += 2) {
        const ridge = new THREE.Mesh(
          new THREE.BoxGeometry(26, 0.25, 0.4),
          new THREE.MeshStandardMaterial({ color: 0x365314, roughness: 1 })
        );
        ridge.position.set(0, 0.15 + (i * 0.4), (i * 15) + r);
        fieldGroup.add(ridge);
      }
    });

    buildingGroup.add(fieldGroup);
  }

  // 9. Foliage & Rural Trees
  function buildFoliage() {
    // Roadside trees along main road
    for (let i = -70; i <= 70; i += 14) {
      const tree1 = createCoconutPalm();
      tree1.position.set(i + (Math.sin(i) * 3), 0, (i * 0.7) - 14);
      foliageGroup.add(tree1);

      const tree2 = createSmallVillageTree();
      tree2.position.set(i - (Math.cos(i) * 3), 0, (i * 0.7) + 14);
      foliageGroup.add(tree2);
    }
  }

  // 10. Interactive 3D Floating Pin Markers
  function buildFloating3DPins() {
    if (!window.VILLAGE_DATA || !window.VILLAGE_DATA.landmarks) return;

    window.VILLAGE_DATA.landmarks.forEach(lm => {
      if (lm.id === 'overview') return;

      const pin = create3DPin(lm.icon, lm.name, lm.id);
      pin.position.set(lm.lookAt[0], lm.lookAt[1] + 9, lm.lookAt[2]);
      pin.userData = { id: lm.id, name: lm.name, type: 'pin' };
      pinGroup.add(pin);
      interactiveObjects.push(pin);
    });
  }

  // Helper: Create 3D Pin Billboard
  function create3DPin(icon, text, landmarkId) {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 128;
    const ctx = canvas.getContext('2d');

    // Rounded rectangle pin bubble
    ctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
    ctx.strokeStyle = landmarkId === 'thiru_house' ? '#f59e0b' : (landmarkId === 'temple' ? '#f97316' : '#10b981');
    ctx.lineWidth = 6;
    roundRect(ctx, 10, 10, 236, 108, 24);
    ctx.fill();
    ctx.stroke();

    // Pin icon & text
    ctx.font = '36px "Segoe UI Emoji", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(icon, 52, 64);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 22px Outfit, sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText(text.split(' ')[0] + ' ' + (text.split(' ')[1] || ''), 92, 54);

    ctx.fillStyle = '#94a3b8';
    ctx.font = '16px Outfit, sans-serif';
    ctx.fillText('Tap to zoom', 92, 82);

    const texture = new THREE.CanvasTexture(canvas);
    const spriteMat = new THREE.SpriteMaterial({ map: texture, depthTest: false, transparent: true });
    const sprite = new THREE.Sprite(spriteMat);
    sprite.scale.set(12, 6, 1);
    return sprite;
  }

  function roundRect(ctx, x, y, width, height, radius) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
  }

  // Tree Generators
  function createCoconutPalm() {
    const palm = new THREE.Group();
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x854d0e, roughness: 0.9 });
    const frondMat = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.6, side: THREE.DoubleSide });

    // Curved trunk
    const trunkGeo = new THREE.CylinderGeometry(0.25, 0.4, 9, 8);
    const trunk = new THREE.Mesh(trunkGeo, trunkMat);
    trunk.position.y = 4.5;
    trunk.rotation.z = (Math.random() - 0.5) * 0.2;
    trunk.castShadow = true;
    palm.add(trunk);

    // Palm fronds
    for (let i = 0; i < 7; i++) {
      const frondGeo = new THREE.PlaneGeometry(1.4, 4.5);
      const frond = new THREE.Mesh(frondGeo, frondMat);
      frond.position.set(0, 9, 0);
      frond.rotation.y = (i * Math.PI) / 3.5;
      frond.rotation.x = Math.PI / 3;
      palm.add(frond);
    }
    return palm;
  }

  function createSmallVillageTree() {
    const tree = new THREE.Group();
    const trunk = new THREE.Mesh(
      new THREE.CylinderGeometry(0.3, 0.45, 3.5, 8),
      new THREE.MeshStandardMaterial({ color: 0x5c4033, roughness: 0.9 })
    );
    trunk.position.y = 1.75;
    trunk.castShadow = true;
    tree.add(trunk);

    const foliage = new THREE.Mesh(
      new THREE.DodecahedronGeometry(2.4, 1),
      new THREE.MeshStandardMaterial({ color: 0x2e7d32, roughness: 0.8 })
    );
    foliage.position.y = 4.2;
    foliage.castShadow = true;
    tree.add(foliage);
    return tree;
  }

  function createLargePeepalTree() {
    const tree = new THREE.Group();
    const trunk = new THREE.Mesh(
      new THREE.CylinderGeometry(0.8, 1.2, 5, 8),
      new THREE.MeshStandardMaterial({ color: 0x4a3728, roughness: 0.9 })
    );
    trunk.position.y = 2.5;
    trunk.castShadow = true;
    tree.add(trunk);

    const foliage = new THREE.Mesh(
      new THREE.DodecahedronGeometry(4.8, 2),
      new THREE.MeshStandardMaterial({ color: 0x166534, roughness: 0.8 })
    );
    foliage.position.y = 7.0;
    foliage.castShadow = true;
    tree.add(foliage);
    return tree;
  }

  function createTractor() {
    const tractor = new THREE.Group();
    const greenMat = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.4 });
    const tireMat = new THREE.MeshStandardMaterial({ color: 0x1c1917, roughness: 0.9 });

    // Chassis
    const body = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.2, 3.4), greenMat);
    body.position.y = 1.0;
    body.castShadow = true;
    tractor.add(body);

    // Big rear wheels
    const rearWheelGeo = new THREE.CylinderGeometry(0.9, 0.9, 0.5, 12);
    rearWheelGeo.rotateZ(Math.PI / 2);
    [-1.2, 1.2].forEach(x => {
      const wheel = new THREE.Mesh(rearWheelGeo, tireMat);
      wheel.position.set(x, 0.9, -0.8);
      tractor.add(wheel);
    });

    // Small front wheels
    const frontWheelGeo = new THREE.CylinderGeometry(0.5, 0.5, 0.35, 12);
    frontWheelGeo.rotateZ(Math.PI / 2);
    [-1.0, 1.0].forEach(x => {
      const wheel = new THREE.Mesh(frontWheelGeo, tireMat);
      wheel.position.set(x, 0.5, 1.2);
      tractor.add(wheel);
    });

    return tractor;
  }

  // --- Smooth Camera Fly-To & Zooming Engine ---
  function zoomToLandmark(landmarkId) {
    if (!window.VILLAGE_DATA || !window.VILLAGE_DATA.landmarks) return;

    const lm = window.VILLAGE_DATA.landmarks.find(l => l.id === landmarkId);
    if (!lm) return;

    state.currentLandmark = landmarkId;

    // Update active nav pill
    dom.navPills.forEach(pill => {
      if (pill.dataset.landmark === landmarkId) pill.classList.add('active');
      else pill.classList.remove('active');
    });

    // Start camera transition
    flyCameraTo(
      new THREE.Vector3(...lm.cameraPos),
      new THREE.Vector3(...lm.lookAt),
      1.8,
      () => {
        if (landmarkId !== 'overview') {
          openLandmarkDrawer(lm);
          playLandmarkSound(landmarkId);
        } else {
          closeLandmarkDrawer();
        }
      }
    );
  }

  function flyCameraTo(targetPos, targetLook, duration = 1.6, callback = null) {
    cameraAnim.active = true;
    cameraAnim.startPos.copy(camera.position);
    cameraAnim.targetPos.copy(targetPos);
    cameraAnim.startLook.copy(cameraAnim.currentLook);
    cameraAnim.targetLook.copy(targetLook);
    cameraAnim.progress = 0;
    cameraAnim.duration = duration;
    cameraAnim.startTime = performance.now();
    cameraAnim.onComplete = callback;

    if (controls) controls.enabled = false;
  }

  function updateCameraAnimation(now) {
    if (!cameraAnim.active) return;

    const elapsed = (now - cameraAnim.startTime) / 1000;
    let t = Math.min(elapsed / cameraAnim.duration, 1.0);

    // Smooth cubic bezier ease-in-out
    const ease = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

    camera.position.lerpVectors(cameraAnim.startPos, cameraAnim.targetPos, ease);
    cameraAnim.currentLook.lerpVectors(cameraAnim.startLook, cameraAnim.targetLook, ease);
    camera.lookAt(cameraAnim.currentLook);

    if (controls) {
      controls.target.copy(cameraAnim.currentLook);
    }

    if (t >= 1.0) {
      cameraAnim.active = false;
      if (controls) controls.enabled = true;
      if (cameraAnim.onComplete) cameraAnim.onComplete();
    }
  }

  // --- Landmark Drawer & Info Card ---
  function openLandmarkDrawer(lm) {
    dom.drawerIcon.textContent = lm.icon;
    dom.drawerCategory.textContent = lm.category;
    dom.drawerTitle.textContent = lm.name;
    dom.drawerSubtitle.textContent = lm.subtitle;
    dom.drawerDesc.textContent = lm.description;

    // Metadata
    dom.drawerMeta.innerHTML = '';
    if (lm.head) {
      dom.drawerMeta.innerHTML += `
        <div class="drawer-meta-item">
          <span class="drawer-meta-label">Head / In-Charge</span>
          <span class="drawer-meta-val">${lm.head}</span>
        </div>`;
    }
    if (lm.timing) {
      dom.drawerMeta.innerHTML += `
        <div class="drawer-meta-item">
          <span class="drawer-meta-label">Timings</span>
          <span class="drawer-meta-val">${lm.timing}</span>
        </div>`;
    }
    if (lm.households) {
      dom.drawerMeta.innerHTML += `
        <div class="drawer-meta-item">
          <span class="drawer-meta-label">Resident Families</span>
          <span class="drawer-meta-val">${lm.households}</span>
        </div>`;
    }

    // Features
    dom.drawerFeatures.innerHTML = '';
    if (lm.features) {
      lm.features.forEach(f => {
        const tag = document.createElement('span');
        tag.className = 'feature-tag';
        tag.textContent = '✓ ' + f;
        dom.drawerFeatures.appendChild(tag);
      });
    }

    // Ward residents link button
    dom.drawerBtnResidents.onclick = () => {
      let filter = 'all';
      if (lm.id === 'temple') filter = 'ward1';
      else if (lm.id === 'thiru_house') filter = 'ward2';
      else if (lm.id === 'school' || lm.id === 'panchayat') filter = 'ward3';
      else if (lm.id === 'west_cluster') filter = 'ward4';

      openCensusModal(filter);
    };

    dom.landmarkDrawer.classList.remove('hidden');
  }

  function closeLandmarkDrawer() {
    dom.landmarkDrawer.classList.add('hidden');
  }

  // --- Time of Day Lighting Cycle ---
  function setTimeOfDay(mode) {
    state.timeOfDay = mode;

    dom.todButtons.forEach(btn => {
      if (btn.dataset.mode === mode) btn.classList.add('active');
      else btn.classList.remove('active');
    });

    if (mode === 'day') {
      scene.background.setHex(0x87ceeb);
      scene.fog.color.setHex(0x87ceeb);
      ambientLight.intensity = 0.45;
      dirLight.intensity = 1.2;
      dirLight.color.setHex(0xfff4d6);
      templeLight.intensity = 0.8;
      thiruGlowLight.intensity = 0.8;
      showToast('☀️ Day mode activated');
    } else if (mode === 'sunset') {
      scene.background.setHex(0xf97316);
      scene.fog.color.setHex(0xf97316);
      ambientLight.intensity = 0.35;
      dirLight.intensity = 0.85;
      dirLight.color.setHex(0xff7700);
      templeLight.intensity = 2.0;
      thiruGlowLight.intensity = 2.0;
      showToast('🌅 Golden Hour / Sunset mode activated');
    } else if (mode === 'night') {
      scene.background.setHex(0x060913);
      scene.fog.color.setHex(0x060913);
      ambientLight.intensity = 0.15;
      dirLight.intensity = 0.15;
      dirLight.color.setHex(0x60a5fa);
      templeLight.intensity = 4.5;
      thiruGlowLight.intensity = 4.0;
      showToast('🌙 Night mode activated with illuminated village lamps');
    }
  }

  // --- Web Audio Procedural Synth (Temple Bell & Ambiance) ---
  function playLandmarkSound(type) {
    if (!state.audioPlaying) return;
    try {
      const ctx = getAudioContext();
      if (type === 'temple') {
        playTempleBell(ctx);
      } else if (type === 'thiru_house') {
        playHeroChime(ctx);
      } else if (type === 'school') {
        playSchoolBell(ctx);
      }
    } catch (e) {
      console.warn('Audio playback error', e);
    }
  }

  function getAudioContext() {
    if (!state.audioCtx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      state.audioCtx = new AudioCtx();
    }
    if (state.audioCtx.state === 'suspended') {
      state.audioCtx.resume();
    }
    return state.audioCtx;
  }

  function playTempleBell(ctx) {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
    osc.frequency.exponentialRampToValueAtTime(580, ctx.currentTime + 2.5);

    gain.gain.setValueAtTime(0.3, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 3.0);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 3.0);
  }

  function playHeroChime(ctx) {
    const freqs = [523.25, 659.25, 783.99, 1046.50]; // C Major chord fanfare
    freqs.forEach((f, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.value = f;

      gain.gain.setValueAtTime(0.12, ctx.currentTime + (i * 0.1));
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + (i * 0.1) + 1.8);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(ctx.currentTime + (i * 0.1));
      osc.stop(ctx.currentTime + (i * 0.1) + 2.0);
    });
  }

  function playSchoolBell(ctx) {
    for (let i = 0; i < 4; i++) {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'square';
      osc.frequency.value = 880;

      gain.gain.setValueAtTime(0.08, ctx.currentTime + (i * 0.22));
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + (i * 0.22) + 0.18);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(ctx.currentTime + (i * 0.22));
      osc.stop(ctx.currentTime + (i * 0.22) + 0.2);
    }
  }

  // --- Automated Cinematic Drone Tour ---
  function startCinematicTour() {
    state.isTouring = true;
    state.tourIndex = 0;
    const landmarks = ['temple', 'school', 'panchayat', 'thiru_house', 'west_cluster', 'fields', 'overview'];
    showToast('🚁 Cinematic Drone Tour Started...');

    function nextStop() {
      if (!state.isTouring) return;
      if (state.tourIndex >= landmarks.length) {
        state.isTouring = false;
        showToast('🏁 Drone Tour Completed!');
        return;
      }
      const lmId = landmarks[state.tourIndex];
      state.tourIndex++;
      zoomToLandmark(lmId);
      setTimeout(nextStop, 5000);
    }
    nextStop();
  }

  // --- Raycasting / Hover & Click Interactions on 3D Buildings ---
  function setupRaycaster() {
    window.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('mousemove', onMouseMove);
  }

  function onMouseMove(e) {
    mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(e.clientY / window.innerHeight) * 2 + 1;
  }

  function onPointerDown(e) {
    // Only raycast if clicking inside canvas and not clicking HUD elements
    if (e.target.closest('.app-header') || e.target.closest('.quick-tools-bar') ||
        e.target.closest('.bottom-stats-bar') || e.target.closest('.landmark-drawer') ||
        e.target.closest('.modal-backdrop')) {
      return;
    }

    mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(e.clientY / window.innerHeight) * 2 + 1;

    raycaster.setFromCamera(mouse, camera);
    const intersects = raycaster.intersectObjects(interactiveObjects, true);

    if (intersects.length > 0) {
      let hit = intersects[0].object;
      while (hit && !hit.userData.id && hit.parent) {
        hit = hit.parent;
      }
      if (hit && hit.userData.id) {
        handleBuildingClick(hit.userData);
      }
    }
  }

  function handleBuildingClick(data) {
    if (data.type === 'landmark' || data.type === 'pin') {
      zoomToLandmark(data.id);
    } else if (data.type === 'house') {
      flyCameraTo(
        new THREE.Vector3(data.coordinates[0], 12, data.coordinates[2] + 16),
        new THREE.Vector3(...data.coordinates),
        1.5,
        () => {
          showToast(`🏡 ${data.name} (${data.houseNo})`);
          openHouseInspector(data);
        }
      );
    }
  }

  function openHouseInspector(houseData) {
    const residents = (window.VILLAGE_DATA.persons || []).filter(p => houseData.residents.includes(p.id));
    dom.drawerIcon.textContent = '🏡';
    dom.drawerCategory.textContent = 'Residential House';
    dom.drawerTitle.textContent = houseData.name;
    dom.drawerSubtitle.textContent = houseData.houseNo;
    dom.drawerDesc.textContent = `Village home in Ward ${houseData.wardId}. Home to ${residents.length} family members.`;

    dom.drawerMeta.innerHTML = residents.map(r => `
      <div class="drawer-meta-item">
        <span class="drawer-meta-label">${r.name} (${r.age}y)</span>
        <span class="drawer-meta-val">${r.occupation}</span>
      </div>
    `).join('');

    dom.drawerFeatures.innerHTML = '';
    dom.drawerBtnResidents.onclick = () => {
      openCensusModal(`house_${houseData.houseNo}`);
    };
    dom.landmarkDrawer.classList.remove('hidden');
  }

  // --- Census Directory (180 Persons) Logic ---
  function openCensusModal(filter = 'all') {
    state.censusFilter = filter;

    // Update filter chips in census modal
    dom.filterChips.forEach(chip => {
      if (chip.dataset.filter === filter) chip.classList.add('active');
      else chip.classList.remove('active');
    });

    renderCensusList();
    dom.censusModal.classList.remove('hidden');
  }

  function closeCensusModal() {
    dom.censusModal.classList.add('hidden');
  }

  function renderCensusList() {
    if (!window.VILLAGE_DATA || !window.VILLAGE_DATA.persons) return;

    let list = [...window.VILLAGE_DATA.persons];
    const q = state.censusSearchQuery.toLowerCase().trim();

    // Text search
    if (q) {
      list = list.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.occupation.toLowerCase().includes(q) ||
        p.role.toLowerCase().includes(q) ||
        p.houseNo.toLowerCase().includes(q) ||
        p.bloodGroup.toLowerCase().includes(q)
      );
    }

    // Filter Chips
    if (state.censusFilter === 'youth') {
      list = list.filter(p => p.age >= 18 && p.age <= 35);
    } else if (state.censusFilter === 'elders') {
      list = list.filter(p => p.age >= 60);
    } else if (state.censusFilter === 'farmers') {
      list = list.filter(p => p.occupation.toLowerCase().includes('farmer') || p.occupation.toLowerCase().includes('cultivator') || p.occupation.toLowerCase().includes('agro') || p.occupation.toLowerCase().includes('orchard'));
    } else if (state.censusFilter === 'students') {
      list = list.filter(p => p.age < 18 || p.occupation.toLowerCase().includes('student'));
    } else if (state.censusFilter === 'leaders') {
      list = list.filter(p => p.isHero || p.role.includes('Leader') || p.role.includes('President') || p.role.includes('Headmaster') || p.role.includes('Priest') || p.role.includes('Archagar'));
    } else if (state.censusFilter === 'ward1') {
      list = list.filter(p => p.wardId === 1);
    } else if (state.censusFilter === 'ward2') {
      list = list.filter(p => p.wardId === 2);
    } else if (state.censusFilter === 'ward3') {
      list = list.filter(p => p.wardId === 3);
    } else if (state.censusFilter === 'ward4') {
      list = list.filter(p => p.wardId === 4);
    } else if (state.censusFilter.startsWith('house_')) {
      const hNo = state.censusFilter.replace('house_', '');
      list = list.filter(p => p.houseNo.includes(hNo));
    }

    // Update count display
    dom.resultsCount.innerHTML = `Showing <strong>${list.length}</strong> of 180 residents`;

    // Render Cards or Table
    if (state.censusViewMode === 'cards') {
      dom.censusContainer.className = 'census-results-container view-mode-cards';
      dom.censusContainer.innerHTML = list.map(p => renderResidentCard(p)).join('');
    } else {
      dom.censusContainer.className = 'census-results-container';
      dom.censusContainer.innerHTML = renderCensusTable(list);
    }

    // Attach click events on "Locate House" & card clicks
    dom.censusContainer.querySelectorAll('.btn-locate-house').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        const pId = parseInt(btn.dataset.pid, 10);
        locateResidentOnMap(pId);
      });
    });

    dom.censusContainer.querySelectorAll('.resident-card, .table-row-person').forEach(el => {
      el.addEventListener('click', () => {
        const pId = parseInt(el.dataset.pid, 10);
        openPersonModal(pId);
      });
    });
  }

  function renderResidentCard(p) {
    const isHero = p.isHero || p.id === 1;
    const heroClass = isHero ? 'card-hero-thiru' : '';
    const avatarHero = isHero ? 'avatar-hero' : '';
    const icon = isHero ? '⭐' : (p.gender === 'Male' ? '👨' : '👩');

    return `
      <div class="resident-card ${heroClass}" data-pid="${p.id}">
        <div class="rcard-top">
          <div class="rcard-avatar ${avatarHero}">
            ${icon}
          </div>
          <div class="rcard-title-group">
            <div class="rcard-name">${p.name}</div>
            <div class="rcard-role">${p.role}</div>
          </div>
          <span class="rcard-blood-badge">${p.bloodGroup}</span>
        </div>

        <div class="rcard-details">
          <div class="rcard-detail-row">
            <i class="fa-solid fa-briefcase"></i>
            <span>${p.occupation}</span>
          </div>
          <div class="rcard-detail-row">
            <i class="fa-solid fa-house-chimney"></i>
            <span>${p.houseNo}</span>
          </div>
          <div class="rcard-detail-row">
            <i class="fa-solid fa-cake-candles"></i>
            <span>${p.age} yrs • ${p.gender}</span>
          </div>
        </div>

        <div class="rcard-bottom-actions">
          <button class="btn-locate-house" data-pid="${p.id}" title="Fly 3D camera to this house">
            <i class="fa-solid fa-location-dot"></i>
            <span>Locate on 3D Map</span>
          </button>
          <button class="btn-view-profile" title="View details">
            Profile
          </button>
        </div>
      </div>
    `;
  }

  function renderCensusTable(list) {
    return `
      <div class="census-table-wrap">
        <table class="census-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Full Name</th>
              <th>Age</th>
              <th>Gender</th>
              <th>Role</th>
              <th>Occupation</th>
              <th>House & Ward</th>
              <th>Blood</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            ${list.map(p => `
              <tr class="table-row-person" data-pid="${p.id}" style="cursor:pointer;">
                <td>#${p.id}</td>
                <td><strong>${p.name}</strong> ${p.isHero ? '⭐' : ''}</td>
                <td>${p.age}</td>
                <td>${p.gender}</td>
                <td><span style="color:#fbbf24;">${p.role}</span></td>
                <td>${p.occupation}</td>
                <td>${p.houseNo}</td>
                <td><span class="rcard-blood-badge">${p.bloodGroup}</span></td>
                <td>
                  <button class="btn-locate-house" data-pid="${p.id}" style="padding:4px 8px;">
                    <i class="fa-solid fa-crosshairs"></i> Fly
                  </button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  }

  function locateResidentOnMap(personId) {
    const person = (window.VILLAGE_DATA.persons || []).find(p => p.id === personId);
    if (!person) return;

    closeCensusModal();
    closeHeroModal();

    showToast(`🎯 Flying to ${person.name}'s Residence...`);

    const coords = person.coordinates || [0, 0, 0];
    flyCameraTo(
      new THREE.Vector3(coords[0], 14, coords[2] + 20),
      new THREE.Vector3(coords[0], coords[1] + 1.5, coords[2]),
      1.8,
      () => {
        showToast(`📍 Arrived at ${person.houseNo}`);
        openPersonModal(personId);
      }
    );
  }

  function openPersonModal(personId) {
    const p = (window.VILLAGE_DATA.persons || []).find(x => x.id === personId);
    if (!p) return;

    dom.personModalContent.innerHTML = `
      <div class="pmodal-header">
        <div class="pmodal-avatar" style="${p.isHero ? 'background:linear-gradient(135deg,#f59e0b,#b45309);' : ''}">
          ${p.isHero ? '⭐' : (p.gender === 'Male' ? '👨' : '👩')}
        </div>
        <div>
          <h3 class="pmodal-name">${p.name}</h3>
          <p class="pmodal-role">${p.role}</p>
        </div>
      </div>

      <div class="pmodal-grid">
        <div class="pmodal-item">
          <label>Age & Gender</label>
          <span>${p.age} yrs • ${p.gender}</span>
        </div>
        <div class="pmodal-item">
          <label>Blood Group</label>
          <span>${p.bloodGroup}</span>
        </div>
        <div class="pmodal-item">
          <label>Occupation</label>
          <span>${p.occupation}</span>
        </div>
        <div class="pmodal-item">
          <label>House & Ward</label>
          <span>${p.houseNo}</span>
        </div>
        <div class="pmodal-item">
          <label>Phone / Helpline</label>
          <span>${p.phone || 'Village Registry'}</span>
        </div>
        <div class="pmodal-item">
          <label>Village Status</label>
          <span>Active Citizen</span>
        </div>
      </div>

      <p class="pmodal-bio">
        <strong>Community Bio:</strong> ${p.bio || p.skills}
      </p>

      <button id="pmodal-btn-fly" class="btn-primary w-full">
        <i class="fa-solid fa-location-crosshairs"></i>
        <span>Zoom Camera to House</span>
      </button>
    `;

    document.getElementById('pmodal-btn-fly').onclick = () => {
      dom.personModal.classList.add('hidden');
      locateResidentOnMap(p.id);
    };

    dom.personModal.classList.remove('hidden');
  }

  // --- Hero Modal (Youth Leader Thiru) Logic ---
  function openHeroModal() {
    dom.heroModal.classList.remove('hidden');
  }

  function closeHeroModal() {
    dom.heroModal.classList.add('hidden');
  }

  // --- Toast Notification Helper ---
  let toastTimer = null;
  function showToast(msg) {
    if (toastTimer) clearTimeout(toastTimer);
    dom.toastMessage.textContent = msg;
    dom.toast.classList.remove('hidden');
    toastTimer = setTimeout(() => {
      dom.toast.classList.add('hidden');
    }, 3200);
  }

  // --- Export Data Helpers ---
  function exportCensusCsv() {
    if (!window.VILLAGE_DATA || !window.VILLAGE_DATA.persons) return;
    const header = ['ID', 'Name', 'Age', 'Gender', 'Role', 'Occupation', 'Ward', 'House', 'BloodGroup', 'Phone'];
    const rows = window.VILLAGE_DATA.persons.map(p => [
      p.id,
      `"${p.name}"`,
      p.age,
      p.gender,
      `"${p.role}"`,
      `"${p.occupation}"`,
      p.wardId,
      `"${p.houseNo}"`,
      p.bloodGroup,
      `"${p.phone}"`
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [header.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'GBG_Village_180_Census.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('📥 Census CSV downloaded successfully!');
  }

  function exportCensusJson() {
    if (!window.VILLAGE_DATA) return;
    const jsonString = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(window.VILLAGE_DATA, null, 2));
    const link = document.createElement('a');
    link.setAttribute('href', jsonString);
    link.setAttribute('download', 'GBG_Village_Data.json');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('📥 JSON data downloaded successfully!');
  }

  // --- Take Photo / Snapshot ---
  function takeSnapshot() {
    renderer.render(scene, camera);
    const dataUrl = renderer.domElement.toDataURL('image/png');
    const link = document.createElement('a');
    link.download = `GBG_Village_3D_${Date.now()}.png`;
    link.href = dataUrl;
    link.click();
    showToast('📸 Village 3D Snapshot saved!');
  }

  // --- UI Event Handlers Setup ---
  function setupEvents() {
    // Resize
    window.addEventListener('resize', onWindowResize);

    // Raycast building clicks
    setupRaycaster();

    // Nav Pills
    dom.navPills.forEach(pill => {
      pill.addEventListener('click', () => {
        zoomToLandmark(pill.dataset.landmark);
      });
    });

    // Header buttons
    dom.btnHero.addEventListener('click', openHeroModal);
    dom.btnCloseHero.addEventListener('click', closeHeroModal);
    dom.heroModal.addEventListener('click', e => {
      if (e.target === dom.heroModal) closeHeroModal();
    });

    dom.btnFlyThiru.addEventListener('click', () => {
      closeHeroModal();
      zoomToLandmark('thiru_house');
    });

    // Census modal
    dom.btnCensus.addEventListener('click', () => openCensusModal('all'));
    dom.btnCloseCensus.addEventListener('click', closeCensusModal);
    dom.censusModal.addEventListener('click', e => {
      if (e.target === dom.censusModal) closeCensusModal();
    });

    // Person modal
    dom.btnClosePerson.addEventListener('click', () => dom.personModal.classList.add('hidden'));
    dom.personModal.addEventListener('click', e => {
      if (e.target === dom.personModal) dom.personModal.classList.add('hidden');
    });

    // Landmark drawer
    dom.btnCloseDrawer.addEventListener('click', closeLandmarkDrawer);

    // Search and filter in census
    dom.searchInput.addEventListener('input', e => {
      state.censusSearchQuery = e.target.value;
      if (state.censusSearchQuery) dom.btnClearSearch.classList.remove('hidden');
      else dom.btnClearSearch.classList.add('hidden');
      renderCensusList();
    });

    dom.btnClearSearch.addEventListener('click', () => {
      dom.searchInput.value = '';
      state.censusSearchQuery = '';
      dom.btnClearSearch.classList.add('hidden');
      renderCensusList();
    });

    dom.filterChips.forEach(chip => {
      chip.addEventListener('click', () => {
        dom.filterChips.forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        state.censusFilter = chip.dataset.filter;
        renderCensusList();
      });
    });

    dom.btnViewCards.addEventListener('click', () => {
      state.censusViewMode = 'cards';
      dom.btnViewCards.classList.add('active');
      dom.btnViewTable.classList.remove('active');
      renderCensusList();
    });

    dom.btnViewTable.addEventListener('click', () => {
      state.censusViewMode = 'table';
      dom.btnViewTable.classList.add('active');
      dom.btnViewCards.classList.remove('active');
      renderCensusList();
    });

    // Time of day buttons
    dom.todButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        setTimeOfDay(btn.dataset.mode);
      });
    });

    // Audio button
    dom.btnSound.addEventListener('click', () => {
      state.audioPlaying = !state.audioPlaying;
      if (state.audioPlaying) {
        dom.btnSound.innerHTML = '<i class="fa-solid fa-volume-high text-amber"></i>';
        showToast('🔔 Village audio enabled (temple bells & chimes on zoom)');
        playLandmarkSound('temple');
      } else {
        dom.btnSound.innerHTML = '<i class="fa-solid fa-volume-xmark"></i>';
        showToast('🔇 Audio muted');
      }
    });

    // Left tools bar
    dom.btnCinematicTour.addEventListener('click', startCinematicTour);
    dom.btnResetCam.addEventListener('click', () => zoomToLandmark('overview'));
    dom.btnToggleLabels.addEventListener('click', () => {
      state.labelsVisible = !state.labelsVisible;
      pinGroup.visible = state.labelsVisible;
      dom.btnToggleLabels.classList.toggle('active', state.labelsVisible);
      showToast(state.labelsVisible ? '📍 3D Pin labels visible' : '🙈 Pin labels hidden');
    });

    dom.btnToggleTexture.addEventListener('click', () => {
      state.satelliteTextureEnabled = !state.satelliteTextureEnabled;
      groundMesh.material.wireframe = !state.satelliteTextureEnabled;
      dom.btnToggleTexture.classList.toggle('active', state.satelliteTextureEnabled);
    });

    dom.btnTakePhoto.addEventListener('click', takeSnapshot);

    // Export buttons
    dom.btnExportCsv.addEventListener('click', exportCensusCsv);
    dom.btnExportJson.addEventListener('click', exportCensusJson);
  }

  function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  }

  // --- Animation Loop ---
  function animate(time) {
    animFrameId = requestAnimationFrame(animate);

    // Smooth camera tween
    updateCameraAnimation(time);

    // OrbitControls update
    if (controls && controls.enabled) {
      controls.update();
    }

    // Flag flapping animation
    flagMeshes.forEach((flag, i) => {
      flag.rotation.y = Math.sin((time * 0.005) + i) * 0.25;
    });

    // Floating 3D pins gentle pulsing
    pinGroup.children.forEach((pin, i) => {
      pin.position.y = 9 + Math.sin((time * 0.003) + (i * 1.5)) * 0.4;
    });

    // Temple light subtle flickering diya flame
    if (templeLight) {
      templeLight.intensity = (state.timeOfDay === 'night' ? 4.5 : 1.2) + Math.sin(time * 0.015) * 0.3;
    }

    renderer.render(scene, camera);
  }

  // Start when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
