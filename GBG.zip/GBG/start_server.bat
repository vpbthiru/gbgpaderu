@echo off
title GBG Village 3D Digital Twin Server
echo ========================================================
echo  Starting GBG Village 3D Digital Twin...
echo ========================================================
echo.
echo Opening http://localhost:3000 in your default browser...
start http://localhost:3000
echo.
node server.js
pause
