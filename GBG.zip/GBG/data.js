const VILLAGE_DATA = {
  "villageName": "GBG Grama Panchayat (Gangavaram)",
  "district": "Rural Development Zone",
  "state": "Tamil Nadu",
  "coordinates": "12°38'15''N 78°22'40''E",
  "totalPopulation": 180,
  "totalHouseholds": 38,
  "youthLeader": {
    "name": "Thiru (Thirumalai R.)",
    "title": "Youth Leader & Rural Changemaker",
    "age": 27,
    "houseNo": "H-201 (Thiru Illam)",
    "tagline": "Empowering Rural Youth • Modern Agriculture • Traditional Values",
    "bio": "Thiru is the beloved youth leader of GBG Village. Over the last 5 years, he has led the 100% solar lighting transition for village streets, established the clean drinking water RO kiosk, championed the annual Sri Hanuman Sports & Kabaddi Trophy, and launched digital learning classes for rural school students.",
    "achievements": [
      {
        "year": "2024",
        "title": "Smart Solar Street Lights",
        "desc": "Installed 48 LED solar street lights connecting Hanuman temple, school and residential wards."
      },
      {
        "year": "2024",
        "title": "Youth Digital Library",
        "desc": "Created 10-computer digital literacy and study room for students at the Community Center."
      },
      {
        "year": "2023",
        "title": "Hanuman Youth Kabaddi Cup",
        "desc": "Annual district-level tournament attracting 24 village teams with huge community participation."
      },
      {
        "year": "2022",
        "title": "Clean Water Mission",
        "desc": "Constructed village RO drinking water kiosk ensuring 100% safe drinking water for all 180 residents."
      },
      {
        "year": "2021",
        "title": "Green Village Drive",
        "desc": "Planted 500+ indigenous banyan, neem and fruit saplings along the main highway and farm paths."
      }
    ],
    "contact": {
      "phone": "+91 98421 77201",
      "email": "thiru.youthgbg@gmail.com",
      "office": "Youth Welfare Center, East Hamlet Road, GBG Village"
    },
    "location": [
      15,
      0.5,
      23
    ]
  },
  "landmarks": [
    {
      "id": "overview",
      "name": "GBG Village Overview",
      "subtitle": "Full Village Bird's Eye View",
      "icon": "🌐",
      "category": "Overview",
      "cameraPos": [
        0,
        85,
        95
      ],
      "lookAt": [
        -5,
        0,
        5
      ],
      "description": "Aerial perspective of GBG Village showing the diagonal main transport road, lush terraced farm plots, the Hanuman Temple, School campus, and Thiru's residential sector."
    },
    {
      "id": "temple",
      "name": "Sri Hanuman Temple (ஆஞ்சநேயர் கோயில்)",
      "subtitle": "Historic Village Shrine & Cultural Anchor",
      "icon": "🕉️",
      "category": "Religious & Heritage",
      "cameraPos": [
        -18,
        12,
        28
      ],
      "lookAt": [
        -18,
        2,
        14
      ],
      "description": "The spiritual heart of GBG Village. Featuring a sculpted sanctum, golden pinnacle Kalash, sacred peepal tree chabutra, and fluttering saffron dhwaja. Hosts the grand annual Hanuman Jayanti and village harvest festival.",
      "head": "Pandian Archagar (Senior Priest)",
      "timing": "5:30 AM - 12:30 PM & 4:30 PM - 8:30 PM",
      "features": [
        "Sacred Banyan Tree",
        "Mandapam Bell",
        "Daily Aarti Lamps",
        "Festival Grounds"
      ]
    },
    {
      "id": "thiru_house",
      "name": "Youth Leader Thiru's Residence",
      "subtitle": "Center for Youth Welfare & Agriculture Excellence",
      "icon": "⭐",
      "category": "Youth Leadership Hub",
      "cameraPos": [
        15,
        14,
        38
      ],
      "lookAt": [
        15,
        2,
        23
      ],
      "description": "The residence of Youth Leader Thiru and the Ramaswamy family. A modern rural farmhouse featuring a solar rooftop, lush farm compound, tractor bay, and open youth meeting veranda where daily community programs are planned.",
      "head": "Thiru (Youth President) & Family",
      "activities": [
        "Youth Assembly & Sports Briefings",
        "Farmer Seed Distribution",
        "Solar Helpdesk",
        "24/7 Community Support"
      ],
      "features": [
        "Solar Rooftop Array",
        "Community Veranda",
        "Tractor & Agro Unit",
        "Garden Groves"
      ]
    },
    {
      "id": "school",
      "name": "Govt. Village Primary & High School",
      "subtitle": "Centre for Academic Excellence & Sports",
      "icon": "🏫",
      "category": "Education",
      "cameraPos": [
        -3,
        14,
        8
      ],
      "lookAt": [
        -3,
        2,
        -9
      ],
      "description": "L-shaped village school campus educating over 65 students from GBG and neighboring hamlets. Features an open assembly playground, Indian National Tricolor flag mast, digital smart lab, and kabaddi arena.",
      "head": "Master Dhanapal M.A., B.Ed. (Headmaster)",
      "features": [
        "National Flag Mast",
        "Digital Smart Classroom",
        "Sports Playground",
        "Free Mid-day Meal Kitchen"
      ]
    },
    {
      "id": "panchayat",
      "name": "Gram Panchayat & Community Hall",
      "subtitle": "Village Governance & Public Services",
      "icon": "🏛️",
      "category": "Administration",
      "cameraPos": [
        -5,
        14,
        10
      ],
      "lookAt": [
        -5,
        2,
        -6
      ],
      "description": "The administrative hub housing the Panchayat Office, E-Seva civic center, cooperative milk collection center, and overhead village water distribution tank.",
      "head": "Natarajan Gowda (Panchayat President)",
      "features": [
        "Overhead Water Tower",
        "Village Dairy Collection",
        "E-Seva Center",
        "Community Assembly Hall"
      ]
    },
    {
      "id": "west_cluster",
      "name": "West Village Settlement (Ramaswamy Ward)",
      "subtitle": "Heritage Village Residential Cluster",
      "icon": "🏘️",
      "category": "Residential Hamlet",
      "cameraPos": [
        -42,
        18,
        4
      ],
      "lookAt": [
        -42,
        2,
        -14
      ],
      "description": "Traditional residential heart of the village featuring 25+ tile-roofed brick homes, narrow shaded streets, ancestral courtyards, cattle sheds, and artisan workshops.",
      "households": "18 Families",
      "features": [
        "Clay-tiled Verandas",
        "Ancestral Courtyards",
        "Artisan Potter Workshops",
        "Cattle Byres"
      ]
    },
    {
      "id": "fields",
      "name": "Green Agricultural Terraces & Groves",
      "subtitle": "Lifeline of Village Economy",
      "icon": "🌾",
      "category": "Agriculture",
      "cameraPos": [
        28,
        25,
        48
      ],
      "lookAt": [
        20,
        0,
        10
      ],
      "description": "Lush stepped farming terraces cultivating paddy, millets, sugarcane, coconut, and mango trees. Fed by borewells and traditional rainwater harvesting ponds.",
      "features": [
        "Organic Paddy Fields",
        "Coconut Groves",
        "Drip Irrigation Units",
        "Canal Waterways"
      ]
    }
  ],
  "wards": [
    {
      "id": 1,
      "name": "Ward 1: Hanuman Temple Street",
      "center": [
        -18,
        0,
        12
      ],
      "houses": 10,
      "prefix": "W1"
    },
    {
      "id": 2,
      "name": "Ward 2: Thiru Garden & East Hamlet",
      "center": [
        16,
        0,
        24
      ],
      "houses": 9,
      "prefix": "W2"
    },
    {
      "id": 3,
      "name": "Ward 3: School Road & Panchayat Center",
      "center": [
        -2,
        0,
        -8
      ],
      "houses": 10,
      "prefix": "W3"
    },
    {
      "id": 4,
      "name": "Ward 4: West Agricultural Colony",
      "center": [
        -42,
        0,
        -14
      ],
      "houses": 9,
      "prefix": "W4"
    }
  ],
  "houses": [
    {
      "wardId": 1,
      "houseNo": "H-101",
      "name": "Temple Archagar Residence",
      "x": -18,
      "z": 14,
      "residents": [
        5,
        6,
        79,
        116,
        153
      ]
    },
    {
      "wardId": 1,
      "houseNo": "H-102",
      "name": "Muthu Gounder Farmhouse",
      "x": -22,
      "z": 16,
      "residents": [
        10,
        44,
        80,
        117,
        154
      ]
    },
    {
      "wardId": 1,
      "houseNo": "H-103",
      "name": "Karpagam Illam",
      "x": -25,
      "z": 12,
      "residents": [
        11,
        45,
        81,
        118,
        155
      ]
    },
    {
      "wardId": 1,
      "houseNo": "H-104",
      "name": "Sri Ganesh Krupa",
      "x": -20,
      "z": 8,
      "residents": [
        12,
        46,
        82,
        119,
        156
      ]
    },
    {
      "wardId": 1,
      "houseNo": "H-105",
      "name": "Anbu Dairy Farm",
      "x": -15,
      "z": 8,
      "residents": [
        13,
        47,
        83,
        120,
        157
      ]
    },
    {
      "wardId": 1,
      "houseNo": "H-106",
      "name": "Shiva Lingam Residence",
      "x": -12,
      "z": 12,
      "residents": [
        14,
        48,
        84,
        121,
        158
      ]
    },
    {
      "wardId": 1,
      "houseNo": "H-107",
      "name": "Devi Nilayam",
      "x": -14,
      "z": 18,
      "residents": [
        15,
        49,
        85,
        122,
        159
      ]
    },
    {
      "wardId": 1,
      "houseNo": "H-108",
      "name": "Saravanan Store House",
      "x": -18,
      "z": 20,
      "residents": [
        16,
        50,
        86,
        123,
        160
      ]
    },
    {
      "wardId": 1,
      "houseNo": "H-109",
      "name": "Venkatesh Agro Quarters",
      "x": -24,
      "z": 20,
      "residents": [
        17,
        51,
        87,
        124,
        161
      ]
    },
    {
      "wardId": 1,
      "houseNo": "H-110",
      "name": "Marimuthu Cottage",
      "x": -28,
      "z": 15,
      "residents": [
        18,
        52,
        88,
        125,
        162
      ]
    },
    {
      "wardId": 2,
      "houseNo": "H-201",
      "name": "Thiru Youth Leader Illam",
      "x": 15,
      "z": 23,
      "residents": [
        1,
        2,
        3,
        4,
        163
      ]
    },
    {
      "wardId": 2,
      "houseNo": "H-202",
      "name": "Arun Youth Brigade Quarters",
      "x": 19,
      "z": 26,
      "residents": [
        19,
        53,
        89,
        126,
        164
      ]
    },
    {
      "wardId": 2,
      "houseNo": "H-203",
      "name": "Selvam Organic Orchard",
      "x": 22,
      "z": 21,
      "residents": [
        20,
        54,
        90,
        127,
        165
      ]
    },
    {
      "wardId": 2,
      "houseNo": "H-204",
      "name": "Karthik Dairy Homestead",
      "x": 13,
      "z": 28,
      "residents": [
        21,
        55,
        91,
        128,
        166
      ]
    },
    {
      "wardId": 2,
      "houseNo": "H-205",
      "name": "Subramani Farmstead",
      "x": 25,
      "z": 24,
      "residents": [
        22,
        56,
        92,
        129,
        167
      ]
    },
    {
      "wardId": 2,
      "houseNo": "H-206",
      "name": "Praveen Agro Green",
      "x": 11,
      "z": 20,
      "residents": [
        23,
        57,
        93,
        130,
        168
      ]
    },
    {
      "wardId": 2,
      "houseNo": "H-207",
      "name": "Sundaram Coconut Grove",
      "x": 20,
      "z": 18,
      "residents": [
        24,
        58,
        94,
        131,
        169
      ]
    },
    {
      "wardId": 2,
      "houseNo": "H-208",
      "name": "Vijay Modern Farm",
      "x": 27,
      "z": 28,
      "residents": [
        25,
        59,
        95,
        132,
        170
      ]
    },
    {
      "wardId": 2,
      "houseNo": "H-209",
      "name": "Balu Cattle Ranch",
      "x": 16,
      "z": 31,
      "residents": [
        26,
        60,
        96,
        133,
        171
      ]
    },
    {
      "wardId": 3,
      "houseNo": "H-301",
      "name": "Headmaster Dhanapal Quarters",
      "x": -3,
      "z": -9,
      "residents": [
        7,
        8,
        97,
        134,
        172
      ]
    },
    {
      "wardId": 3,
      "houseNo": "H-302",
      "name": "Panchayat President Residence",
      "x": -5,
      "z": -6,
      "residents": [
        9,
        61,
        98,
        135,
        173
      ]
    },
    {
      "wardId": 3,
      "houseNo": "H-303",
      "name": "Village Post & Tele Center House",
      "x": 1,
      "z": -7,
      "residents": [
        27,
        62,
        99,
        136,
        174
      ]
    },
    {
      "wardId": 3,
      "houseNo": "H-304",
      "name": "VHN Health Worker Quarters",
      "x": 4,
      "z": -10,
      "residents": [
        28,
        63,
        100,
        137,
        175
      ]
    },
    {
      "wardId": 3,
      "houseNo": "H-305",
      "name": "Chai & Grocery Corner Residence",
      "x": -7,
      "z": -11,
      "residents": [
        29,
        64,
        101,
        138,
        176
      ]
    },
    {
      "wardId": 3,
      "houseNo": "H-306",
      "name": "Senthil Tailoring House",
      "x": -1,
      "z": -13,
      "residents": [
        30,
        65,
        102,
        139,
        177
      ]
    },
    {
      "wardId": 3,
      "houseNo": "H-307",
      "name": "Logu Electrical Works House",
      "x": 3,
      "z": -14,
      "residents": [
        31,
        66,
        103,
        140,
        178
      ]
    },
    {
      "wardId": 3,
      "houseNo": "H-308",
      "name": "Kannan Teacher Cottage",
      "x": -8,
      "z": -15,
      "residents": [
        32,
        67,
        104,
        141,
        179
      ]
    },
    {
      "wardId": 3,
      "houseNo": "H-309",
      "name": "Anganwadi Supervisor Residence",
      "x": 6,
      "z": -8,
      "residents": [
        33,
        68,
        105,
        142,
        180
      ]
    },
    {
      "wardId": 3,
      "houseNo": "H-310",
      "name": "Co-op Dairy Secretary Home",
      "x": -4,
      "z": -18,
      "residents": [
        34,
        69,
        106,
        143
      ]
    },
    {
      "wardId": 4,
      "houseNo": "H-401",
      "name": "Perumal Heritage Home",
      "x": -40,
      "z": -12,
      "residents": [
        35,
        70,
        107,
        144
      ]
    },
    {
      "wardId": 4,
      "houseNo": "H-402",
      "name": "Chinnathambi Homestead",
      "x": -44,
      "z": -15,
      "residents": [
        36,
        71,
        108,
        145
      ]
    },
    {
      "wardId": 4,
      "houseNo": "H-403",
      "name": "Velu Potter & Artisan House",
      "x": -38,
      "z": -17,
      "residents": [
        37,
        72,
        109,
        146
      ]
    },
    {
      "wardId": 4,
      "houseNo": "H-404",
      "name": "Rajesh Youth Sports House",
      "x": -46,
      "z": -10,
      "residents": [
        38,
        73,
        110,
        147
      ]
    },
    {
      "wardId": 4,
      "houseNo": "H-405",
      "name": "Palani Weaver House",
      "x": -36,
      "z": -11,
      "residents": [
        39,
        74,
        111,
        148
      ]
    },
    {
      "wardId": 4,
      "houseNo": "H-406",
      "name": "Ganesan Farmer Villa",
      "x": -43,
      "z": -20,
      "residents": [
        40,
        75,
        112,
        149
      ]
    },
    {
      "wardId": 4,
      "houseNo": "H-407",
      "name": "Ayyappan Cattle Shed Home",
      "x": -48,
      "z": -16,
      "residents": [
        41,
        76,
        113,
        150
      ]
    },
    {
      "wardId": 4,
      "houseNo": "H-408",
      "name": "Dharmalingam Agro House",
      "x": -35,
      "z": -19,
      "residents": [
        42,
        77,
        114,
        151
      ]
    },
    {
      "wardId": 4,
      "houseNo": "H-409",
      "name": "Madhavan Green Field Cottage",
      "x": -50,
      "z": -12,
      "residents": [
        43,
        78,
        115,
        152
      ]
    }
  ],
  "persons": [
    {
      "id": 1,
      "name": "Thiru (Thirumalai R.)",
      "age": 27,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-201 (Thiru Illam)",
      "role": "Village Youth Leader & Social Pioneer",
      "occupation": "Agripreneur & Youth President",
      "bloodGroup": "O+",
      "phone": "+91 98421 77201",
      "skills": "Youth Welfare, Solar Street Lighting Project, Drinking Water RO Plants, Hanuman Sports Festival Organiser",
      "bio": "Dynamic youth leader driving modern education, sports tournaments, solar energy and tree plantation drives across GBG village.",
      "coordinates": [
        15,
        0.5,
        23
      ],
      "isHero": true,
      "photoBadge": "⭐ YOUTH LEADER"
    },
    {
      "id": 2,
      "name": "Ramaswamy Kounder",
      "age": 58,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-201 (Thiru Illam)",
      "role": "Father of Thiru / Senior Farmer",
      "occupation": "Traditional Paddy & Sugarcane Farmer",
      "bloodGroup": "B+",
      "phone": "+91 94432 11202",
      "skills": "Organic water conservation, cattle breeding",
      "bio": "Respected farming patriarch in the village. Father of Youth Leader Thiru.",
      "coordinates": [
        15,
        0.5,
        23
      ]
    },
    {
      "id": 3,
      "name": "Kalyani Ramaswamy",
      "age": 52,
      "gender": "Female",
      "wardId": 2,
      "houseNo": "H-201 (Thiru Illam)",
      "role": "Mother of Thiru / SHG Leader",
      "occupation": "Dairy Management & SHG Treasurer",
      "bloodGroup": "O+",
      "phone": "+91 94432 11203",
      "skills": "Women Self Help Group mentor, traditional herbal remedies",
      "bio": "Community matriarch who heads the Sri Lakshmi Women Self Help Group.",
      "coordinates": [
        15,
        0.5,
        23
      ]
    },
    {
      "id": 4,
      "name": "Deepa Ramaswamy",
      "age": 23,
      "gender": "Female",
      "wardId": 2,
      "houseNo": "H-201 (Thiru Illam)",
      "role": "Sister of Thiru",
      "occupation": "M.Sc. Agriculture Graduate & Educator",
      "bloodGroup": "A+",
      "phone": "+91 98421 77204",
      "skills": "Soil health analysis, digital literacy for school children",
      "bio": "Conducts evening digital classes for village students alongside Thiru.",
      "coordinates": [
        15,
        0.5,
        23
      ]
    },
    {
      "id": 5,
      "name": "Pandian Archagar",
      "age": 64,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-101 (Temple Archagar Residence)",
      "role": "Head Priest (Sri Hanuman Temple)",
      "occupation": "Vedic Scholar & Temple Archagar",
      "bloodGroup": "A+",
      "phone": "+91 94420 88101",
      "skills": "Vedic rituals, Hanuman Jayanti grand celebration head, community blessings",
      "bio": "Serving the village Hanuman Temple for over 40 years with devotional hymns and festival leadership.",
      "coordinates": [
        -18,
        0.5,
        14
      ]
    },
    {
      "id": 6,
      "name": "Meenakshi Pandian",
      "age": 59,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-101 (Temple Archagar Residence)",
      "role": "Temple Committee Member",
      "occupation": "Devotional Singer & Garland Artisan",
      "bloodGroup": "O+",
      "phone": "+91 94420 88102",
      "skills": "Floral decorations for deities, devotional music",
      "bio": "Coordinates the daily floral offerings and prasadam for Hanuman Temple visitors.",
      "coordinates": [
        -18,
        0.5,
        14
      ]
    },
    {
      "id": 7,
      "name": "Master Dhanapal M.A., B.Ed.",
      "age": 51,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-301 (School Master Quarters)",
      "role": "Headmaster (Govt. Village School)",
      "occupation": "Headmaster & Science Educator",
      "bloodGroup": "B+",
      "phone": "+91 94883 44301",
      "skills": "Science education, 100% pass rate mentor, national science club guide",
      "bio": "Under his leadership, GBG Village School won the Taluk Best Rural School Award in 2024.",
      "coordinates": [
        -3,
        0.5,
        -9
      ]
    },
    {
      "id": 8,
      "name": "Radha Dhanapal",
      "age": 46,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-301 (School Master Quarters)",
      "role": "Senior Primary Teacher",
      "occupation": "Mathematics & Tamil Teacher",
      "bloodGroup": "A+",
      "phone": "+91 94883 44302",
      "skills": "Vedic mathematics, drama and arts coaching",
      "bio": "Nurturing generations of village children with fond warmth and educational discipline.",
      "coordinates": [
        -3,
        0.5,
        -9
      ]
    },
    {
      "id": 9,
      "name": "Natarajan Gowda",
      "age": 62,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-302 (Panchayat Bhavan Road)",
      "role": "Gram Panchayat President",
      "occupation": "Civic Administration & Senior Planter",
      "bloodGroup": "AB+",
      "phone": "+91 94431 55301",
      "skills": "Village infrastructure schemes, road connectivity, dispute resolution",
      "bio": "Senior village elder working closely with Youth Leader Thiru to modernise village amenities.",
      "coordinates": [
        -5,
        0.5,
        -6
      ]
    },
    {
      "id": 10,
      "name": "Lakshmi Kounder",
      "age": 33,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-102 (Muthu Gounder Farmhouse)",
      "role": "Resident",
      "occupation": "High School Student",
      "bloodGroup": "B+",
      "phone": "+91 94712 13274",
      "skills": "High School Student • Village Community Member",
      "bio": "Active resident of Muthu Gounder Farmhouse in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -22.72,
        0.5,
        16.41
      ]
    },
    {
      "id": 11,
      "name": "Thiru Reddy",
      "age": 14,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-103 (Karpagam Illam)",
      "role": "High School Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "B+",
      "phone": "+91 98820 43624",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Karpagam Illam in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -24.39,
        0.5,
        12.2
      ]
    },
    {
      "id": 12,
      "name": "Parvathi Gounder",
      "age": 46,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-104 (Sri Ganesh Krupa)",
      "role": "Resident",
      "occupation": "Tailoring & Garment Unit Leader",
      "bloodGroup": "A-",
      "phone": "+91 97817 91195",
      "skills": "Tailoring & Garment Unit Leader • Village Community Member",
      "bio": "Active resident of Sri Ganesh Krupa in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -20.53,
        0.5,
        7.41
      ]
    },
    {
      "id": 13,
      "name": "Selvam Naidu",
      "age": 18,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-105 (Anbu Dairy Farm)",
      "role": "Youth Brigade Member",
      "occupation": "Young Agripreneur",
      "bloodGroup": "O+",
      "phone": "+91 94394 81704",
      "skills": "Young Agripreneur • Village Community Member",
      "bio": "Active resident of Anbu Dairy Farm in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -15.36,
        0.5,
        7.91
      ]
    },
    {
      "id": 14,
      "name": "Meena Pillai",
      "age": 20,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-106 (Shiva Lingam Residence)",
      "role": "College Youth / SHG Volunteer",
      "occupation": "Auto & Tractor Driver",
      "bloodGroup": "O+",
      "phone": "+91 92653 57848",
      "skills": "Auto & Tractor Driver • Village Community Member",
      "bio": "Active resident of Shiva Lingam Residence in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -12.11,
        0.5,
        12.68
      ]
    },
    {
      "id": 15,
      "name": "Murugan Thevar",
      "age": 49,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-107 (Devi Nilayam)",
      "role": "Resident",
      "occupation": "Auto & Tractor Driver",
      "bloodGroup": "A-",
      "phone": "+91 98973 86810",
      "skills": "Auto & Tractor Driver • Village Community Member",
      "bio": "Active resident of Devi Nilayam in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -13.7,
        0.5,
        17.9
      ]
    },
    {
      "id": 16,
      "name": "Anitha Mudaliar",
      "age": 64,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-108 (Saravanan Store House)",
      "role": "Village Elder & Mentor",
      "occupation": "Retired Farmer / Elder",
      "bloodGroup": "O-",
      "phone": "+91 90904 59861",
      "skills": "Retired Farmer / Elder • Village Community Member",
      "bio": "Active resident of Saravanan Store House in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -17.26,
        0.5,
        19.8
      ]
    },
    {
      "id": 17,
      "name": "Karthik Achari",
      "age": 46,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-109 (Venkatesh Agro Quarters)",
      "role": "Resident",
      "occupation": "Grocery Store Merchant",
      "bloodGroup": "A+",
      "phone": "+91 98486 41597",
      "skills": "Grocery Store Merchant • Village Community Member",
      "bio": "Active resident of Venkatesh Agro Quarters in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -24.1,
        0.5,
        20.19
      ]
    },
    {
      "id": 18,
      "name": "Kavitha Yadav",
      "age": 57,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-110 (Marimuthu Cottage)",
      "role": "Resident",
      "occupation": "Organic Farmer",
      "bloodGroup": "B-",
      "phone": "+91 98432 76498",
      "skills": "Organic Farmer • Village Community Member",
      "bio": "Active resident of Marimuthu Cottage in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -27.38,
        0.5,
        14.55
      ]
    },
    {
      "id": 19,
      "name": "Balu Chettiar",
      "age": 21,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-202 (Arun Youth Brigade Quarters)",
      "role": "Youth Brigade Member",
      "occupation": "Young Agripreneur",
      "bloodGroup": "B-",
      "phone": "+91 97558 70055",
      "skills": "Young Agripreneur • Village Community Member",
      "bio": "Active resident of Arun Youth Brigade Quarters in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        19.51,
        0.5,
        26.31
      ]
    },
    {
      "id": 20,
      "name": "Geetha Gowda",
      "age": 22,
      "gender": "Female",
      "wardId": 2,
      "houseNo": "H-203 (Selvam Organic Orchard)",
      "role": "College Youth / SHG Volunteer",
      "occupation": "Young Agripreneur",
      "bloodGroup": "O-",
      "phone": "+91 90541 33219",
      "skills": "Young Agripreneur • Village Community Member",
      "bio": "Active resident of Selvam Organic Orchard in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        22.1,
        0.5,
        21.21
      ]
    },
    {
      "id": 21,
      "name": "Ramesh Nadar",
      "age": 45,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-204 (Karthik Dairy Homestead)",
      "role": "Resident",
      "occupation": "Gram Panchayat Member",
      "bloodGroup": "O-",
      "phone": "+91 98198 30305",
      "skills": "Gram Panchayat Member • Village Community Member",
      "bio": "Active resident of Karthik Dairy Homestead in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        12.74,
        0.5,
        27.47
      ]
    },
    {
      "id": 22,
      "name": "Radha Iyer",
      "age": 26,
      "gender": "Female",
      "wardId": 2,
      "houseNo": "H-205 (Subramani Farmstead)",
      "role": "College Youth / SHG Volunteer",
      "occupation": "Young Agripreneur",
      "bloodGroup": "O+",
      "phone": "+91 97421 45148",
      "skills": "Young Agripreneur • Village Community Member",
      "bio": "Active resident of Subramani Farmstead in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        24.87,
        0.5,
        24.1
      ]
    },
    {
      "id": 23,
      "name": "Suresh Varma",
      "age": 7,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-206 (Praveen Agro Green)",
      "role": "Primary Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "A+",
      "phone": "+91 96675 26289",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Praveen Agro Green in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        11.7,
        0.5,
        19.37
      ]
    },
    {
      "id": 24,
      "name": "Sangeetha Patil",
      "age": 67,
      "gender": "Female",
      "wardId": 2,
      "houseNo": "H-207 (Sundaram Coconut Grove)",
      "role": "Village Elder & Mentor",
      "occupation": "Temple & Heritage Advisor",
      "bloodGroup": "AB+",
      "phone": "+91 90496 86278",
      "skills": "Temple & Heritage Advisor • Village Community Member",
      "bio": "Active resident of Sundaram Coconut Grove in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        20.33,
        0.5,
        17.59
      ]
    },
    {
      "id": 25,
      "name": "Manikandan Nayakar",
      "age": 15,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-208 (Vijay Modern Farm)",
      "role": "High School Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "O-",
      "phone": "+91 94012 26233",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Vijay Modern Farm in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        27.1,
        0.5,
        28.25
      ]
    },
    {
      "id": 26,
      "name": "Revathi Kounder",
      "age": 65,
      "gender": "Female",
      "wardId": 2,
      "houseNo": "H-209 (Balu Cattle Ranch)",
      "role": "Village Elder & Mentor",
      "occupation": "Temple & Heritage Advisor",
      "bloodGroup": "AB+",
      "phone": "+91 95151 72735",
      "skills": "Temple & Heritage Advisor • Village Community Member",
      "bio": "Active resident of Balu Cattle Ranch in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        16.21,
        0.5,
        30.98
      ]
    },
    {
      "id": 27,
      "name": "Saravanan Reddy",
      "age": 22,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-303 (Village Post & Tele Center House)",
      "role": "Youth Brigade Member",
      "occupation": "Young Agripreneur",
      "bloodGroup": "A+",
      "phone": "+91 95097 86877",
      "skills": "Young Agripreneur • Village Community Member",
      "bio": "Active resident of Village Post & Tele Center House in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        1.29,
        0.5,
        -7.36
      ]
    },
    {
      "id": 28,
      "name": "Deepa Gounder",
      "age": 7,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-304 (VHN Health Worker Quarters)",
      "role": "Primary Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "A+",
      "phone": "+91 94217 76868",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of VHN Health Worker Quarters in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        3.78,
        0.5,
        -9.3
      ]
    },
    {
      "id": 29,
      "name": "Gopal Naidu",
      "age": 42,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-305 (Chai & Grocery Corner Residence)",
      "role": "Resident",
      "occupation": "Mason & Builder",
      "bloodGroup": "A+",
      "phone": "+91 93924 82653",
      "skills": "Mason & Builder • Village Community Member",
      "bio": "Active resident of Chai & Grocery Corner Residence in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -7.43,
        0.5,
        -10.83
      ]
    },
    {
      "id": 30,
      "name": "Priya Pillai",
      "age": 41,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-306 (Senthil Tailoring House)",
      "role": "Resident",
      "occupation": "Temple Priest / Archagar",
      "bloodGroup": "O-",
      "phone": "+91 98628 58355",
      "skills": "Temple Priest / Archagar • Village Community Member",
      "bio": "Active resident of Senthil Tailoring House in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -1.3,
        0.5,
        -12.29
      ]
    },
    {
      "id": 31,
      "name": "Rajesh Thevar",
      "age": 14,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-307 (Logu Electrical Works House)",
      "role": "High School Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "A+",
      "phone": "+91 93578 26793",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Logu Electrical Works House in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        3.23,
        0.5,
        -13.94
      ]
    },
    {
      "id": 32,
      "name": "Sudha Mudaliar",
      "age": 51,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-308 (Kannan Teacher Cottage)",
      "role": "Resident",
      "occupation": "Organic Farmer",
      "bloodGroup": "O-",
      "phone": "+91 95171 97942",
      "skills": "Organic Farmer • Village Community Member",
      "bio": "Active resident of Kannan Teacher Cottage in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -8.25,
        0.5,
        -14.79
      ]
    },
    {
      "id": 33,
      "name": "Venkatesh Achari",
      "age": 31,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-309 (Anganwadi Supervisor Residence)",
      "role": "Resident",
      "occupation": "Horticulturist (Mango & Coconut)",
      "bloodGroup": "A+",
      "phone": "+91 95949 92831",
      "skills": "Horticulturist (Mango & Coconut) • Village Community Member",
      "bio": "Active resident of Anganwadi Supervisor Residence in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        5.97,
        0.5,
        -8.25
      ]
    },
    {
      "id": 34,
      "name": "Bhavani Yadav",
      "age": 47,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-310 (Co-op Dairy Secretary Home)",
      "role": "Resident",
      "occupation": "Grocery Store Merchant",
      "bloodGroup": "B-",
      "phone": "+91 90107 44123",
      "skills": "Grocery Store Merchant • Village Community Member",
      "bio": "Active resident of Co-op Dairy Secretary Home in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -4.28,
        0.5,
        -18.32
      ]
    },
    {
      "id": 35,
      "name": "Anbu Chettiar",
      "age": 20,
      "gender": "Male",
      "wardId": 4,
      "houseNo": "H-401 (Perumal Heritage Home)",
      "role": "Youth Brigade Member",
      "occupation": "College Student",
      "bloodGroup": "B+",
      "phone": "+91 97937 73938",
      "skills": "College Student • Village Community Member",
      "bio": "Active resident of Perumal Heritage Home in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -40.52,
        0.5,
        -12.7
      ]
    },
    {
      "id": 36,
      "name": "Vasanthi Gowda",
      "age": 42,
      "gender": "Female",
      "wardId": 4,
      "houseNo": "H-402 (Chinnathambi Homestead)",
      "role": "Resident",
      "occupation": "College Student (Agri)",
      "bloodGroup": "A-",
      "phone": "+91 98169 91338",
      "skills": "College Student (Agri) • Village Community Member",
      "bio": "Active resident of Chinnathambi Homestead in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -43.33,
        0.5,
        -15.46
      ]
    },
    {
      "id": 37,
      "name": "Senthil Nadar",
      "age": 23,
      "gender": "Male",
      "wardId": 4,
      "houseNo": "H-403 (Velu Potter & Artisan House)",
      "role": "Youth Brigade Member",
      "occupation": "Young Agripreneur",
      "bloodGroup": "A+",
      "phone": "+91 96931 67559",
      "skills": "Young Agripreneur • Village Community Member",
      "bio": "Active resident of Velu Potter & Artisan House in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -38.04,
        0.5,
        -17.63
      ]
    },
    {
      "id": 38,
      "name": "Kamala Iyer",
      "age": 6,
      "gender": "Female",
      "wardId": 4,
      "houseNo": "H-404 (Rajesh Youth Sports House)",
      "role": "Primary Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "A-",
      "phone": "+91 97258 77778",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Rajesh Youth Sports House in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -46.66,
        0.5,
        -9.34
      ]
    },
    {
      "id": 39,
      "name": "Praveen Varma",
      "age": 42,
      "gender": "Male",
      "wardId": 4,
      "houseNo": "H-405 (Palani Weaver House)",
      "role": "Resident",
      "occupation": "Tailoring & Garment Unit Leader",
      "bloodGroup": "B-",
      "phone": "+91 95596 17257",
      "skills": "Tailoring & Garment Unit Leader • Village Community Member",
      "bio": "Active resident of Palani Weaver House in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -36.63,
        0.5,
        -11.6
      ]
    },
    {
      "id": 40,
      "name": "Sumathi Patil",
      "age": 9,
      "gender": "Female",
      "wardId": 4,
      "houseNo": "H-406 (Ganesan Farmer Villa)",
      "role": "Primary Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "AB+",
      "phone": "+91 99367 81256",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Ganesan Farmer Villa in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -42.89,
        0.5,
        -20.14
      ]
    },
    {
      "id": 41,
      "name": "Dinesh Nayakar",
      "age": 30,
      "gender": "Male",
      "wardId": 4,
      "houseNo": "H-407 (Ayyappan Cattle Shed Home)",
      "role": "Resident",
      "occupation": "Grocery Store Merchant",
      "bloodGroup": "O-",
      "phone": "+91 93874 25559",
      "skills": "Grocery Store Merchant • Village Community Member",
      "bio": "Active resident of Ayyappan Cattle Shed Home in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -48.2,
        0.5,
        -15.55
      ]
    },
    {
      "id": 42,
      "name": "Devi Kounder",
      "age": 56,
      "gender": "Female",
      "wardId": 4,
      "houseNo": "H-408 (Dharmalingam Agro House)",
      "role": "Resident",
      "occupation": "Temple Priest / Archagar",
      "bloodGroup": "B-",
      "phone": "+91 99216 77946",
      "skills": "Temple Priest / Archagar • Village Community Member",
      "bio": "Active resident of Dharmalingam Agro House in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -35.25,
        0.5,
        -19.7
      ]
    },
    {
      "id": 43,
      "name": "Chandran Reddy",
      "age": 19,
      "gender": "Male",
      "wardId": 4,
      "houseNo": "H-409 (Madhavan Green Field Cottage)",
      "role": "Youth Brigade Member",
      "occupation": "College Student (Agri)",
      "bloodGroup": "O+",
      "phone": "+91 94675 20183",
      "skills": "College Student (Agri) • Village Community Member",
      "bio": "Active resident of Madhavan Green Field Cottage in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -50.46,
        0.5,
        -12.67
      ]
    },
    {
      "id": 44,
      "name": "Shanthi Gounder",
      "age": 26,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-102 (Muthu Gounder Farmhouse)",
      "role": "College Youth / SHG Volunteer",
      "occupation": "Young Agripreneur",
      "bloodGroup": "B+",
      "phone": "+91 92859 79768",
      "skills": "Young Agripreneur • Village Community Member",
      "bio": "Active resident of Muthu Gounder Farmhouse in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -22.69,
        0.5,
        15.85
      ]
    },
    {
      "id": 45,
      "name": "Sundaram Naidu",
      "age": 47,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-103 (Karpagam Illam)",
      "role": "Resident",
      "occupation": "Mason & Builder",
      "bloodGroup": "O-",
      "phone": "+91 96206 54857",
      "skills": "Mason & Builder • Village Community Member",
      "bio": "Active resident of Karpagam Illam in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -25.32,
        0.5,
        12.01
      ]
    },
    {
      "id": 46,
      "name": "Vijaya Pillai",
      "age": 17,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-104 (Sri Ganesh Krupa)",
      "role": "High School Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "B-",
      "phone": "+91 99219 61892",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Sri Ganesh Krupa in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -19.91,
        0.5,
        8.5
      ]
    },
    {
      "id": 47,
      "name": "Muthu Thevar",
      "age": 64,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-105 (Anbu Dairy Farm)",
      "role": "Village Elder & Mentor",
      "occupation": "Retired Farmer / Elder",
      "bloodGroup": "A-",
      "phone": "+91 92540 57202",
      "skills": "Retired Farmer / Elder • Village Community Member",
      "bio": "Active resident of Anbu Dairy Farm in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -14.77,
        0.5,
        8.41
      ]
    },
    {
      "id": 48,
      "name": "Gomathi Mudaliar",
      "age": 34,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-106 (Shiva Lingam Residence)",
      "role": "Resident",
      "occupation": "Electrical Technician",
      "bloodGroup": "B+",
      "phone": "+91 92982 52591",
      "skills": "Electrical Technician • Village Community Member",
      "bio": "Active resident of Shiva Lingam Residence in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -11.91,
        0.5,
        11.9
      ]
    },
    {
      "id": 49,
      "name": "Arun Achari",
      "age": 73,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-107 (Devi Nilayam)",
      "role": "Village Elder & Mentor",
      "occupation": "Retired Farmer / Elder",
      "bloodGroup": "B-",
      "phone": "+91 91412 41463",
      "skills": "Retired Farmer / Elder • Village Community Member",
      "bio": "Active resident of Devi Nilayam in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -14.23,
        0.5,
        17.66
      ]
    },
    {
      "id": 50,
      "name": "Saradha Yadav",
      "age": 6,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-108 (Saravanan Store House)",
      "role": "Primary Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "AB+",
      "phone": "+91 94510 67004",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Saravanan Store House in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -17.81,
        0.5,
        19.37
      ]
    },
    {
      "id": 51,
      "name": "Vijay Chettiar",
      "age": 74,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-109 (Venkatesh Agro Quarters)",
      "role": "Village Elder & Mentor",
      "occupation": "Retired Farmer / Elder",
      "bloodGroup": "AB+",
      "phone": "+91 90263 97822",
      "skills": "Retired Farmer / Elder • Village Community Member",
      "bio": "Active resident of Venkatesh Agro Quarters in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -24.04,
        0.5,
        19.86
      ]
    },
    {
      "id": 52,
      "name": "Malathi Gowda",
      "age": 25,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-110 (Marimuthu Cottage)",
      "role": "College Youth / SHG Volunteer",
      "occupation": "College Student",
      "bloodGroup": "O+",
      "phone": "+91 91281 76049",
      "skills": "College Student • Village Community Member",
      "bio": "Active resident of Marimuthu Cottage in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -27.33,
        0.5,
        15.24
      ]
    },
    {
      "id": 53,
      "name": "Kannan Nadar",
      "age": 55,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-202 (Arun Youth Brigade Quarters)",
      "role": "Resident",
      "occupation": "School Teacher",
      "bloodGroup": "B+",
      "phone": "+91 97165 87737",
      "skills": "School Teacher • Village Community Member",
      "bio": "Active resident of Arun Youth Brigade Quarters in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        18.85,
        0.5,
        25.68
      ]
    },
    {
      "id": 54,
      "name": "Karpagam Iyer",
      "age": 15,
      "gender": "Female",
      "wardId": 2,
      "houseNo": "H-203 (Selvam Organic Orchard)",
      "role": "High School Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "A+",
      "phone": "+91 96542 77711",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Selvam Organic Orchard in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        21.78,
        0.5,
        21.48
      ]
    },
    {
      "id": 55,
      "name": "Shankar Varma",
      "age": 37,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-204 (Karthik Dairy Homestead)",
      "role": "Resident",
      "occupation": "High School Student",
      "bloodGroup": "O-",
      "phone": "+91 96675 35316",
      "skills": "High School Student • Village Community Member",
      "bio": "Active resident of Karthik Dairy Homestead in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        12.39,
        0.5,
        27.54
      ]
    },
    {
      "id": 56,
      "name": "Mallika Patil",
      "age": 55,
      "gender": "Female",
      "wardId": 2,
      "houseNo": "H-205 (Subramani Farmstead)",
      "role": "Resident",
      "occupation": "College Student (Agri)",
      "bloodGroup": "O-",
      "phone": "+91 95699 70499",
      "skills": "College Student (Agri) • Village Community Member",
      "bio": "Active resident of Subramani Farmstead in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        24.57,
        0.5,
        24.03
      ]
    },
    {
      "id": 57,
      "name": "Pandian Nayakar",
      "age": 61,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-206 (Praveen Agro Green)",
      "role": "Village Elder & Mentor",
      "occupation": "Retired Farmer / Elder",
      "bloodGroup": "B-",
      "phone": "+91 99966 62013",
      "skills": "Retired Farmer / Elder • Village Community Member",
      "bio": "Active resident of Praveen Agro Green in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        11.57,
        0.5,
        19.65
      ]
    },
    {
      "id": 58,
      "name": "Renuka Kounder",
      "age": 22,
      "gender": "Female",
      "wardId": 2,
      "houseNo": "H-207 (Sundaram Coconut Grove)",
      "role": "College Youth / SHG Volunteer",
      "occupation": "Village Artisan / Carpenter",
      "bloodGroup": "O+",
      "phone": "+91 98032 56191",
      "skills": "Village Artisan / Carpenter • Village Community Member",
      "bio": "Active resident of Sundaram Coconut Grove in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        20.64,
        0.5,
        17.75
      ]
    },
    {
      "id": 59,
      "name": "Velu Reddy",
      "age": 37,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-208 (Vijay Modern Farm)",
      "role": "Resident",
      "occupation": "Temple Priest / Archagar",
      "bloodGroup": "A-",
      "phone": "+91 90385 32852",
      "skills": "Temple Priest / Archagar • Village Community Member",
      "bio": "Active resident of Vijay Modern Farm in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        27.7,
        0.5,
        28.74
      ]
    },
    {
      "id": 60,
      "name": "Nandhini Gounder",
      "age": 57,
      "gender": "Female",
      "wardId": 2,
      "houseNo": "H-209 (Balu Cattle Ranch)",
      "role": "Resident",
      "occupation": "Electrical Technician",
      "bloodGroup": "AB+",
      "phone": "+91 90411 40747",
      "skills": "Electrical Technician • Village Community Member",
      "bio": "Active resident of Balu Cattle Ranch in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        15.35,
        0.5,
        31.28
      ]
    },
    {
      "id": 61,
      "name": "Natarajan Naidu",
      "age": 27,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-302 (Panchayat President Residence)",
      "role": "Youth Brigade Member",
      "occupation": "College Student",
      "bloodGroup": "AB+",
      "phone": "+91 92001 15026",
      "skills": "College Student • Village Community Member",
      "bio": "Active resident of Panchayat President Residence in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -4.94,
        0.5,
        -6.35
      ]
    },
    {
      "id": 62,
      "name": "Sindhu Pillai",
      "age": 6,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-303 (Village Post & Tele Center House)",
      "role": "Primary Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "B+",
      "phone": "+91 94694 42851",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Village Post & Tele Center House in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        0.5,
        0.5,
        -7.53
      ]
    },
    {
      "id": 63,
      "name": "Dhanapal Thevar",
      "age": 8,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-304 (VHN Health Worker Quarters)",
      "role": "Primary Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "A+",
      "phone": "+91 90561 95504",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of VHN Health Worker Quarters in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        4.18,
        0.5,
        -9.99
      ]
    },
    {
      "id": 64,
      "name": "Poornima Mudaliar",
      "age": 26,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-305 (Chai & Grocery Corner Residence)",
      "role": "College Youth / SHG Volunteer",
      "occupation": "College Student",
      "bloodGroup": "A+",
      "phone": "+91 99701 39885",
      "skills": "College Student • Village Community Member",
      "bio": "Active resident of Chai & Grocery Corner Residence in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -7.06,
        0.5,
        -10.44
      ]
    },
    {
      "id": 65,
      "name": "Raghavan Achari",
      "age": 30,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-306 (Senthil Tailoring House)",
      "role": "Resident",
      "occupation": "Mason & Builder",
      "bloodGroup": "B+",
      "phone": "+91 90044 91625",
      "skills": "Mason & Builder • Village Community Member",
      "bio": "Active resident of Senthil Tailoring House in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -1.48,
        0.5,
        -13.51
      ]
    },
    {
      "id": 66,
      "name": "Subhashini Yadav",
      "age": 48,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-307 (Logu Electrical Works House)",
      "role": "Resident",
      "occupation": "School Teacher",
      "bloodGroup": "A+",
      "phone": "+91 97493 22845",
      "skills": "School Teacher • Village Community Member",
      "bio": "Active resident of Logu Electrical Works House in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        3.06,
        0.5,
        -13.73
      ]
    },
    {
      "id": 67,
      "name": "Subramani Chettiar",
      "age": 24,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-308 (Kannan Teacher Cottage)",
      "role": "Youth Brigade Member",
      "occupation": "Young Agripreneur",
      "bloodGroup": "O-",
      "phone": "+91 95804 92305",
      "skills": "Young Agripreneur • Village Community Member",
      "bio": "Active resident of Kannan Teacher Cottage in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -8.4,
        0.5,
        -14.46
      ]
    },
    {
      "id": 68,
      "name": "Kokila Gowda",
      "age": 39,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-309 (Anganwadi Supervisor Residence)",
      "role": "Resident",
      "occupation": "Retired Postal Officer",
      "bloodGroup": "AB+",
      "phone": "+91 98839 53316",
      "skills": "Retired Postal Officer • Village Community Member",
      "bio": "Active resident of Anganwadi Supervisor Residence in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        5.28,
        0.5,
        -8.19
      ]
    },
    {
      "id": 69,
      "name": "Ravi Nadar",
      "age": 37,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-310 (Co-op Dairy Secretary Home)",
      "role": "Resident",
      "occupation": "Tailoring & Garment Unit Leader",
      "bloodGroup": "O+",
      "phone": "+91 96180 88043",
      "skills": "Tailoring & Garment Unit Leader • Village Community Member",
      "bio": "Active resident of Co-op Dairy Secretary Home in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -4.69,
        0.5,
        -18.7
      ]
    },
    {
      "id": 70,
      "name": "Yamuna Iyer",
      "age": 7,
      "gender": "Female",
      "wardId": 4,
      "houseNo": "H-401 (Perumal Heritage Home)",
      "role": "Primary Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "B+",
      "phone": "+91 99942 35584",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Perumal Heritage Home in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -39.37,
        0.5,
        -12.6
      ]
    },
    {
      "id": 71,
      "name": "Kumaran Varma",
      "age": 49,
      "gender": "Male",
      "wardId": 4,
      "houseNo": "H-402 (Chinnathambi Homestead)",
      "role": "Resident",
      "occupation": "Anganwadi Worker",
      "bloodGroup": "O-",
      "phone": "+91 97655 33587",
      "skills": "Anganwadi Worker • Village Community Member",
      "bio": "Active resident of Chinnathambi Homestead in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -44.59,
        0.5,
        -14.75
      ]
    },
    {
      "id": 72,
      "name": "Selvi Patil",
      "age": 47,
      "gender": "Female",
      "wardId": 4,
      "houseNo": "H-403 (Velu Potter & Artisan House)",
      "role": "Resident",
      "occupation": "School Teacher",
      "bloodGroup": "O-",
      "phone": "+91 90974 64948",
      "skills": "School Teacher • Village Community Member",
      "bio": "Active resident of Velu Potter & Artisan House in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -37.34,
        0.5,
        -17.73
      ]
    },
    {
      "id": 73,
      "name": "Loganathan Nayakar",
      "age": 6,
      "gender": "Male",
      "wardId": 4,
      "houseNo": "H-404 (Rajesh Youth Sports House)",
      "role": "Primary Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "B+",
      "phone": "+91 92312 36695",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Rajesh Youth Sports House in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -46.33,
        0.5,
        -10.54
      ]
    },
    {
      "id": 74,
      "name": "Bharathi Kounder",
      "age": 64,
      "gender": "Female",
      "wardId": 4,
      "houseNo": "H-405 (Palani Weaver House)",
      "role": "Village Elder & Mentor",
      "occupation": "Temple & Heritage Advisor",
      "bloodGroup": "B+",
      "phone": "+91 99980 72311",
      "skills": "Temple & Heritage Advisor • Village Community Member",
      "bio": "Active resident of Palani Weaver House in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -36.47,
        0.5,
        -11.15
      ]
    },
    {
      "id": 75,
      "name": "Shiva Reddy",
      "age": 41,
      "gender": "Male",
      "wardId": 4,
      "houseNo": "H-406 (Ganesan Farmer Villa)",
      "role": "Resident",
      "occupation": "Village Artisan / Carpenter",
      "bloodGroup": "B+",
      "phone": "+91 97402 90812",
      "skills": "Village Artisan / Carpenter • Village Community Member",
      "bio": "Active resident of Ganesan Farmer Villa in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -43.62,
        0.5,
        -19.52
      ]
    },
    {
      "id": 76,
      "name": "Abirami Gounder",
      "age": 14,
      "gender": "Female",
      "wardId": 4,
      "houseNo": "H-407 (Ayyappan Cattle Shed Home)",
      "role": "High School Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "AB+",
      "phone": "+91 97996 50768",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Ayyappan Cattle Shed Home in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -47.95,
        0.5,
        -16.75
      ]
    },
    {
      "id": 77,
      "name": "Govind Naidu",
      "age": 18,
      "gender": "Male",
      "wardId": 4,
      "houseNo": "H-408 (Dharmalingam Agro House)",
      "role": "Youth Brigade Member",
      "occupation": "Young Agripreneur",
      "bloodGroup": "O+",
      "phone": "+91 94795 44666",
      "skills": "Young Agripreneur • Village Community Member",
      "bio": "Active resident of Dharmalingam Agro House in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -34.95,
        0.5,
        -18.86
      ]
    },
    {
      "id": 78,
      "name": "Padma Pillai",
      "age": 31,
      "gender": "Female",
      "wardId": 4,
      "houseNo": "H-409 (Madhavan Green Field Cottage)",
      "role": "Resident",
      "occupation": "Auto & Tractor Driver",
      "bloodGroup": "A+",
      "phone": "+91 90215 34562",
      "skills": "Auto & Tractor Driver • Village Community Member",
      "bio": "Active resident of Madhavan Green Field Cottage in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -49.25,
        0.5,
        -11.6
      ]
    },
    {
      "id": 79,
      "name": "Ramu Thevar",
      "age": 25,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-101 (Temple Archagar Residence)",
      "role": "Youth Brigade Member",
      "occupation": "College Student",
      "bloodGroup": "A-",
      "phone": "+91 96550 54659",
      "skills": "College Student • Village Community Member",
      "bio": "Active resident of Temple Archagar Residence in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -18.17,
        0.5,
        14.49
      ]
    },
    {
      "id": 80,
      "name": "Uma Mudaliar",
      "age": 24,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-102 (Muthu Gounder Farmhouse)",
      "role": "College Youth / SHG Volunteer",
      "occupation": "Young Agripreneur",
      "bloodGroup": "A-",
      "phone": "+91 90583 88500",
      "skills": "Young Agripreneur • Village Community Member",
      "bio": "Active resident of Muthu Gounder Farmhouse in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -22.44,
        0.5,
        15.95
      ]
    },
    {
      "id": 81,
      "name": "Somu Achari",
      "age": 17,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-103 (Karpagam Illam)",
      "role": "High School Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "A-",
      "phone": "+91 93024 19156",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Karpagam Illam in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -25.68,
        0.5,
        12.55
      ]
    },
    {
      "id": 82,
      "name": "Lalitha Yadav",
      "age": 37,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-104 (Sri Ganesh Krupa)",
      "role": "Resident",
      "occupation": "School Teacher",
      "bloodGroup": "A-",
      "phone": "+91 93557 63223",
      "skills": "School Teacher • Village Community Member",
      "bio": "Active resident of Sri Ganesh Krupa in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -19.67,
        0.5,
        7.59
      ]
    },
    {
      "id": 83,
      "name": "Elango Chettiar",
      "age": 13,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-105 (Anbu Dairy Farm)",
      "role": "High School Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "A+",
      "phone": "+91 95122 62044",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Anbu Dairy Farm in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -15.7,
        0.5,
        8.38
      ]
    },
    {
      "id": 84,
      "name": "Chitra Gowda",
      "age": 8,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-106 (Shiva Lingam Residence)",
      "role": "Primary Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "B+",
      "phone": "+91 91702 35281",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Shiva Lingam Residence in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -12.2,
        0.5,
        11.82
      ]
    },
    {
      "id": 85,
      "name": "Madhavan Nadar",
      "age": 19,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-107 (Devi Nilayam)",
      "role": "Youth Brigade Member",
      "occupation": "College Student",
      "bloodGroup": "AB+",
      "phone": "+91 90870 27941",
      "skills": "College Student • Village Community Member",
      "bio": "Active resident of Devi Nilayam in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -13.28,
        0.5,
        18.62
      ]
    },
    {
      "id": 86,
      "name": "Swathi Iyer",
      "age": 47,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-108 (Saravanan Store House)",
      "role": "Resident",
      "occupation": "Anganwadi Worker",
      "bloodGroup": "O+",
      "phone": "+91 94053 86466",
      "skills": "Anganwadi Worker • Village Community Member",
      "bio": "Active resident of Saravanan Store House in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -17.84,
        0.5,
        19.91
      ]
    },
    {
      "id": 87,
      "name": "Aravind Varma",
      "age": 75,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-109 (Venkatesh Agro Quarters)",
      "role": "Village Elder & Mentor",
      "occupation": "Temple & Heritage Advisor",
      "bloodGroup": "AB+",
      "phone": "+91 93278 21917",
      "skills": "Temple & Heritage Advisor • Village Community Member",
      "bio": "Active resident of Venkatesh Agro Quarters in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -24.38,
        0.5,
        20.22
      ]
    },
    {
      "id": 88,
      "name": "Divya Patil",
      "age": 23,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-110 (Marimuthu Cottage)",
      "role": "College Youth / SHG Volunteer",
      "occupation": "Temple Priest / Archagar",
      "bloodGroup": "O-",
      "phone": "+91 91463 62723",
      "skills": "Temple Priest / Archagar • Village Community Member",
      "bio": "Active resident of Marimuthu Cottage in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -27.49,
        0.5,
        15.48
      ]
    },
    {
      "id": 89,
      "name": "Harish Nayakar",
      "age": 40,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-202 (Arun Youth Brigade Quarters)",
      "role": "Resident",
      "occupation": "Auto & Tractor Driver",
      "bloodGroup": "AB+",
      "phone": "+91 98486 21964",
      "skills": "Auto & Tractor Driver • Village Community Member",
      "bio": "Active resident of Arun Youth Brigade Quarters in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        18.97,
        0.5,
        26.29
      ]
    },
    {
      "id": 90,
      "name": "Kasturi Kounder",
      "age": 12,
      "gender": "Female",
      "wardId": 2,
      "houseNo": "H-203 (Selvam Organic Orchard)",
      "role": "High School Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "A-",
      "phone": "+91 90992 93554",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Selvam Organic Orchard in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        22.36,
        0.5,
        21.25
      ]
    },
    {
      "id": 91,
      "name": "Vasanth Reddy",
      "age": 58,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-204 (Karthik Dairy Homestead)",
      "role": "Resident",
      "occupation": "Horticulturist (Mango & Coconut)",
      "bloodGroup": "B+",
      "phone": "+91 97974 91822",
      "skills": "Horticulturist (Mango & Coconut) • Village Community Member",
      "bio": "Active resident of Karthik Dairy Homestead in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        13.43,
        0.5,
        27.79
      ]
    },
    {
      "id": 92,
      "name": "Menaka Gounder",
      "age": 48,
      "gender": "Female",
      "wardId": 2,
      "houseNo": "H-205 (Subramani Farmstead)",
      "role": "Resident",
      "occupation": "Paddy Cultivator",
      "bloodGroup": "A+",
      "phone": "+91 93884 90876",
      "skills": "Paddy Cultivator • Village Community Member",
      "bio": "Active resident of Subramani Farmstead in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        25.25,
        0.5,
        24.36
      ]
    },
    {
      "id": 93,
      "name": "Vignesh Naidu",
      "age": 45,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-206 (Praveen Agro Green)",
      "role": "Resident",
      "occupation": "Horticulturist (Mango & Coconut)",
      "bloodGroup": "O-",
      "phone": "+91 94287 94282",
      "skills": "Horticulturist (Mango & Coconut) • Village Community Member",
      "bio": "Active resident of Praveen Agro Green in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        10.92,
        0.5,
        19.76
      ]
    },
    {
      "id": 94,
      "name": "Padmini Pillai",
      "age": 29,
      "gender": "Female",
      "wardId": 2,
      "houseNo": "H-207 (Sundaram Coconut Grove)",
      "role": "Resident",
      "occupation": "Gram Panchayat Member",
      "bloodGroup": "B+",
      "phone": "+91 90138 93792",
      "skills": "Gram Panchayat Member • Village Community Member",
      "bio": "Active resident of Sundaram Coconut Grove in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        19.32,
        0.5,
        17.43
      ]
    },
    {
      "id": 95,
      "name": "Prabhu Thevar",
      "age": 6,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-208 (Vijay Modern Farm)",
      "role": "Primary Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "O-",
      "phone": "+91 95988 73584",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Vijay Modern Farm in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        27.38,
        0.5,
        28.15
      ]
    },
    {
      "id": 96,
      "name": "Alamelu Mudaliar",
      "age": 28,
      "gender": "Female",
      "wardId": 2,
      "houseNo": "H-209 (Balu Cattle Ranch)",
      "role": "College Youth / SHG Volunteer",
      "occupation": "College Student",
      "bloodGroup": "O-",
      "phone": "+91 94871 85488",
      "skills": "College Student • Village Community Member",
      "bio": "Active resident of Balu Cattle Ranch in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        16.31,
        0.5,
        30.97
      ]
    },
    {
      "id": 97,
      "name": "Balamurugan Achari",
      "age": 83,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-301 (Headmaster Dhanapal Quarters)",
      "role": "Village Elder & Mentor",
      "occupation": "Retired Farmer / Elder",
      "bloodGroup": "A+",
      "phone": "+91 93995 17094",
      "skills": "Retired Farmer / Elder • Village Community Member",
      "bio": "Active resident of Headmaster Dhanapal Quarters in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -3.03,
        0.5,
        -8.61
      ]
    },
    {
      "id": 98,
      "name": "Kalyani Yadav",
      "age": 45,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-302 (Panchayat President Residence)",
      "role": "Resident",
      "occupation": "Cattle Care Specialist",
      "bloodGroup": "O-",
      "phone": "+91 92699 52541",
      "skills": "Cattle Care Specialist • Village Community Member",
      "bio": "Active resident of Panchayat President Residence in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -5.39,
        0.5,
        -6.33
      ]
    },
    {
      "id": 99,
      "name": "Krishnan Chettiar",
      "age": 30,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-303 (Village Post & Tele Center House)",
      "role": "Resident",
      "occupation": "College Student (B.Tech)",
      "bloodGroup": "B-",
      "phone": "+91 98973 30716",
      "skills": "College Student (B.Tech) • Village Community Member",
      "bio": "Active resident of Village Post & Tele Center House in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        0.79,
        0.5,
        -7.75
      ]
    },
    {
      "id": 100,
      "name": "Sujatha Gowda",
      "age": 34,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-304 (VHN Health Worker Quarters)",
      "role": "Resident",
      "occupation": "Paddy Cultivator",
      "bloodGroup": "A-",
      "phone": "+91 90223 12771",
      "skills": "Paddy Cultivator • Village Community Member",
      "bio": "Active resident of VHN Health Worker Quarters in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        4.57,
        0.5,
        -10.44
      ]
    },
    {
      "id": 101,
      "name": "Ramachandran Nadar",
      "age": 8,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-305 (Chai & Grocery Corner Residence)",
      "role": "Primary Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "AB+",
      "phone": "+91 97252 80407",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Chai & Grocery Corner Residence in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -7.56,
        0.5,
        -11.48
      ]
    },
    {
      "id": 102,
      "name": "Mohana Iyer",
      "age": 35,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-306 (Senthil Tailoring House)",
      "role": "Resident",
      "occupation": "Tailoring & Garment Unit Leader",
      "bloodGroup": "AB+",
      "phone": "+91 92757 24194",
      "skills": "Tailoring & Garment Unit Leader • Village Community Member",
      "bio": "Active resident of Senthil Tailoring House in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -1.29,
        0.5,
        -13.41
      ]
    },
    {
      "id": 103,
      "name": "Ganesan Varma",
      "age": 57,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-307 (Logu Electrical Works House)",
      "role": "Resident",
      "occupation": "Youth Club Coordinator",
      "bloodGroup": "O+",
      "phone": "+91 93793 37395",
      "skills": "Youth Club Coordinator • Village Community Member",
      "bio": "Active resident of Logu Electrical Works House in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        3.37,
        0.5,
        -13.75
      ]
    },
    {
      "id": 104,
      "name": "Rajalakshmi Patil",
      "age": 26,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-308 (Kannan Teacher Cottage)",
      "role": "College Youth / SHG Volunteer",
      "occupation": "College Student",
      "bloodGroup": "B-",
      "phone": "+91 91805 29613",
      "skills": "College Student • Village Community Member",
      "bio": "Active resident of Kannan Teacher Cottage in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -7.36,
        0.5,
        -14.93
      ]
    },
    {
      "id": 105,
      "name": "Mani Nayakar",
      "age": 15,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-309 (Anganwadi Supervisor Residence)",
      "role": "High School Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "AB+",
      "phone": "+91 99798 69927",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Anganwadi Supervisor Residence in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        6.75,
        0.5,
        -8.65
      ]
    },
    {
      "id": 106,
      "name": "Lakshmi Kounder",
      "age": 75,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-310 (Co-op Dairy Secretary Home)",
      "role": "Village Elder & Mentor",
      "occupation": "Temple & Heritage Advisor",
      "bloodGroup": "O+",
      "phone": "+91 93298 20333",
      "skills": "Temple & Heritage Advisor • Village Community Member",
      "bio": "Active resident of Co-op Dairy Secretary Home in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -3.99,
        0.5,
        -17.69
      ]
    },
    {
      "id": 107,
      "name": "Perumal Reddy",
      "age": 21,
      "gender": "Male",
      "wardId": 4,
      "houseNo": "H-401 (Perumal Heritage Home)",
      "role": "Youth Brigade Member",
      "occupation": "Young Agripreneur",
      "bloodGroup": "A+",
      "phone": "+91 96226 69750",
      "skills": "Young Agripreneur • Village Community Member",
      "bio": "Active resident of Perumal Heritage Home in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -40.22,
        0.5,
        -12.18
      ]
    },
    {
      "id": 108,
      "name": "Parvathi Gounder",
      "age": 53,
      "gender": "Female",
      "wardId": 4,
      "houseNo": "H-402 (Chinnathambi Homestead)",
      "role": "Resident",
      "occupation": "High School Student",
      "bloodGroup": "O-",
      "phone": "+91 97360 28893",
      "skills": "High School Student • Village Community Member",
      "bio": "Active resident of Chinnathambi Homestead in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -44.16,
        0.5,
        -14.94
      ]
    },
    {
      "id": 109,
      "name": "Marimuthu Naidu",
      "age": 25,
      "gender": "Male",
      "wardId": 4,
      "houseNo": "H-403 (Velu Potter & Artisan House)",
      "role": "Youth Brigade Member",
      "occupation": "Young Agripreneur",
      "bloodGroup": "AB+",
      "phone": "+91 90107 97659",
      "skills": "Young Agripreneur • Village Community Member",
      "bio": "Active resident of Velu Potter & Artisan House in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -38.49,
        0.5,
        -17.07
      ]
    },
    {
      "id": 110,
      "name": "Meena Pillai",
      "age": 33,
      "gender": "Female",
      "wardId": 4,
      "houseNo": "H-404 (Rajesh Youth Sports House)",
      "role": "Resident",
      "occupation": "Village Artisan / Carpenter",
      "bloodGroup": "B-",
      "phone": "+91 97469 48856",
      "skills": "Village Artisan / Carpenter • Village Community Member",
      "bio": "Active resident of Rajesh Youth Sports House in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -46.36,
        0.5,
        -9.84
      ]
    },
    {
      "id": 111,
      "name": "Palani Thevar",
      "age": 12,
      "gender": "Male",
      "wardId": 4,
      "houseNo": "H-405 (Palani Weaver House)",
      "role": "High School Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "B-",
      "phone": "+91 98239 42998",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Palani Weaver House in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -35.81,
        0.5,
        -11.29
      ]
    },
    {
      "id": 112,
      "name": "Anitha Mudaliar",
      "age": 39,
      "gender": "Female",
      "wardId": 4,
      "houseNo": "H-406 (Ganesan Farmer Villa)",
      "role": "Resident",
      "occupation": "Gram Panchayat Member",
      "bloodGroup": "A-",
      "phone": "+91 94777 37342",
      "skills": "Gram Panchayat Member • Village Community Member",
      "bio": "Active resident of Ganesan Farmer Villa in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -43.14,
        0.5,
        -19.98
      ]
    },
    {
      "id": 113,
      "name": "Chinnathambi Achari",
      "age": 56,
      "gender": "Male",
      "wardId": 4,
      "houseNo": "H-407 (Ayyappan Cattle Shed Home)",
      "role": "Resident",
      "occupation": "Mason & Builder",
      "bloodGroup": "A-",
      "phone": "+91 98807 62894",
      "skills": "Mason & Builder • Village Community Member",
      "bio": "Active resident of Ayyappan Cattle Shed Home in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -48.38,
        0.5,
        -15.86
      ]
    },
    {
      "id": 114,
      "name": "Kavitha Yadav",
      "age": 10,
      "gender": "Female",
      "wardId": 4,
      "houseNo": "H-408 (Dharmalingam Agro House)",
      "role": "Primary Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "A-",
      "phone": "+91 96727 98211",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Dharmalingam Agro House in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -34.79,
        0.5,
        -18.46
      ]
    },
    {
      "id": 115,
      "name": "Ayyappan Chettiar",
      "age": 24,
      "gender": "Male",
      "wardId": 4,
      "houseNo": "H-409 (Madhavan Green Field Cottage)",
      "role": "Youth Brigade Member",
      "occupation": "Young Agripreneur",
      "bloodGroup": "O-",
      "phone": "+91 98068 12862",
      "skills": "Young Agripreneur • Village Community Member",
      "bio": "Active resident of Madhavan Green Field Cottage in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -49.82,
        0.5,
        -11.78
      ]
    },
    {
      "id": 116,
      "name": "Geetha Gowda",
      "age": 19,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-101 (Temple Archagar Residence)",
      "role": "College Youth / SHG Volunteer",
      "occupation": "Young Agripreneur",
      "bloodGroup": "O+",
      "phone": "+91 97587 29143",
      "skills": "Young Agripreneur • Village Community Member",
      "bio": "Active resident of Temple Archagar Residence in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -17.47,
        0.5,
        13.83
      ]
    },
    {
      "id": 117,
      "name": "Dharmalingam Nadar",
      "age": 46,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-102 (Muthu Gounder Farmhouse)",
      "role": "Resident",
      "occupation": "Organic Farmer",
      "bloodGroup": "O-",
      "phone": "+91 93993 76193",
      "skills": "Organic Farmer • Village Community Member",
      "bio": "Active resident of Muthu Gounder Farmhouse in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -22.58,
        0.5,
        16.33
      ]
    },
    {
      "id": 118,
      "name": "Radha Iyer",
      "age": 28,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-103 (Karpagam Illam)",
      "role": "College Youth / SHG Volunteer",
      "occupation": "Organic Farmer",
      "bloodGroup": "B+",
      "phone": "+91 99063 89516",
      "skills": "Organic Farmer • Village Community Member",
      "bio": "Active resident of Karpagam Illam in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -24.58,
        0.5,
        12.24
      ]
    },
    {
      "id": 119,
      "name": "Thiru Varma",
      "age": 10,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-104 (Sri Ganesh Krupa)",
      "role": "Primary Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "O-",
      "phone": "+91 93675 63358",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Sri Ganesh Krupa in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -19.54,
        0.5,
        7.71
      ]
    },
    {
      "id": 120,
      "name": "Sangeetha Patil",
      "age": 51,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-105 (Anbu Dairy Farm)",
      "role": "Resident",
      "occupation": "Self-Help Group (SHG) Leader",
      "bloodGroup": "O-",
      "phone": "+91 95620 60989",
      "skills": "Self-Help Group (SHG) Leader • Village Community Member",
      "bio": "Active resident of Anbu Dairy Farm in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -14.52,
        0.5,
        7.29
      ]
    },
    {
      "id": 121,
      "name": "Selvam Nayakar",
      "age": 36,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-106 (Shiva Lingam Residence)",
      "role": "Resident",
      "occupation": "Tailoring & Garment Unit Leader",
      "bloodGroup": "AB+",
      "phone": "+91 98990 27055",
      "skills": "Tailoring & Garment Unit Leader • Village Community Member",
      "bio": "Active resident of Shiva Lingam Residence in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -12.55,
        0.5,
        11.85
      ]
    },
    {
      "id": 122,
      "name": "Revathi Kounder",
      "age": 56,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-107 (Devi Nilayam)",
      "role": "Resident",
      "occupation": "Gram Panchayat Member",
      "bloodGroup": "A-",
      "phone": "+91 96472 90492",
      "skills": "Gram Panchayat Member • Village Community Member",
      "bio": "Active resident of Devi Nilayam in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -13.89,
        0.5,
        17.81
      ]
    },
    {
      "id": 123,
      "name": "Murugan Reddy",
      "age": 44,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-108 (Saravanan Store House)",
      "role": "Resident",
      "occupation": "Tailoring & Garment Unit Leader",
      "bloodGroup": "O-",
      "phone": "+91 98753 91446",
      "skills": "Tailoring & Garment Unit Leader • Village Community Member",
      "bio": "Active resident of Saravanan Store House in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -17.39,
        0.5,
        19.62
      ]
    },
    {
      "id": 124,
      "name": "Deepa Gounder",
      "age": 47,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-109 (Venkatesh Agro Quarters)",
      "role": "Resident",
      "occupation": "Horticulturist (Mango & Coconut)",
      "bloodGroup": "A-",
      "phone": "+91 95571 35894",
      "skills": "Horticulturist (Mango & Coconut) • Village Community Member",
      "bio": "Active resident of Venkatesh Agro Quarters in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -24.45,
        0.5,
        19.71
      ]
    },
    {
      "id": 125,
      "name": "Karthik Naidu",
      "age": 29,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-110 (Marimuthu Cottage)",
      "role": "Resident",
      "occupation": "Electrical Technician",
      "bloodGroup": "B-",
      "phone": "+91 94262 77311",
      "skills": "Electrical Technician • Village Community Member",
      "bio": "Active resident of Marimuthu Cottage in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -28.36,
        0.5,
        15.69
      ]
    },
    {
      "id": 126,
      "name": "Priya Pillai",
      "age": 26,
      "gender": "Female",
      "wardId": 2,
      "houseNo": "H-202 (Arun Youth Brigade Quarters)",
      "role": "College Youth / SHG Volunteer",
      "occupation": "College Student",
      "bloodGroup": "O+",
      "phone": "+91 93851 70979",
      "skills": "College Student • Village Community Member",
      "bio": "Active resident of Arun Youth Brigade Quarters in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        18.66,
        0.5,
        25.52
      ]
    },
    {
      "id": 127,
      "name": "Balu Thevar",
      "age": 77,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-203 (Selvam Organic Orchard)",
      "role": "Village Elder & Mentor",
      "occupation": "Temple & Heritage Advisor",
      "bloodGroup": "A-",
      "phone": "+91 92558 14439",
      "skills": "Temple & Heritage Advisor • Village Community Member",
      "bio": "Active resident of Selvam Organic Orchard in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        21.47,
        0.5,
        21.03
      ]
    },
    {
      "id": 128,
      "name": "Sudha Mudaliar",
      "age": 53,
      "gender": "Female",
      "wardId": 2,
      "houseNo": "H-204 (Karthik Dairy Homestead)",
      "role": "Resident",
      "occupation": "Mason & Builder",
      "bloodGroup": "O-",
      "phone": "+91 97578 11593",
      "skills": "Mason & Builder • Village Community Member",
      "bio": "Active resident of Karthik Dairy Homestead in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        13.05,
        0.5,
        27.98
      ]
    },
    {
      "id": 129,
      "name": "Ramesh Achari",
      "age": 49,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-205 (Subramani Farmstead)",
      "role": "Resident",
      "occupation": "Organic Farmer",
      "bloodGroup": "O-",
      "phone": "+91 97649 25379",
      "skills": "Organic Farmer • Village Community Member",
      "bio": "Active resident of Subramani Farmstead in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        24.35,
        0.5,
        23.49
      ]
    },
    {
      "id": 130,
      "name": "Bhavani Yadav",
      "age": 26,
      "gender": "Female",
      "wardId": 2,
      "houseNo": "H-206 (Praveen Agro Green)",
      "role": "College Youth / SHG Volunteer",
      "occupation": "College Student",
      "bloodGroup": "AB+",
      "phone": "+91 91094 61050",
      "skills": "College Student • Village Community Member",
      "bio": "Active resident of Praveen Agro Green in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        10.91,
        0.5,
        20.53
      ]
    },
    {
      "id": 131,
      "name": "Suresh Chettiar",
      "age": 28,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-207 (Sundaram Coconut Grove)",
      "role": "Youth Brigade Member",
      "occupation": "Young Agripreneur",
      "bloodGroup": "B-",
      "phone": "+91 96302 85733",
      "skills": "Young Agripreneur • Village Community Member",
      "bio": "Active resident of Sundaram Coconut Grove in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        19.8,
        0.5,
        18.58
      ]
    },
    {
      "id": 132,
      "name": "Vasanthi Gowda",
      "age": 64,
      "gender": "Female",
      "wardId": 2,
      "houseNo": "H-208 (Vijay Modern Farm)",
      "role": "Village Elder & Mentor",
      "occupation": "Retired Farmer / Elder",
      "bloodGroup": "A+",
      "phone": "+91 96879 77723",
      "skills": "Retired Farmer / Elder • Village Community Member",
      "bio": "Active resident of Vijay Modern Farm in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        27.08,
        0.5,
        27.66
      ]
    },
    {
      "id": 133,
      "name": "Manikandan Nadar",
      "age": 8,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-209 (Balu Cattle Ranch)",
      "role": "Primary Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "A-",
      "phone": "+91 98099 78203",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Balu Cattle Ranch in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        15.7,
        0.5,
        30.35
      ]
    },
    {
      "id": 134,
      "name": "Kamala Iyer",
      "age": 6,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-301 (Headmaster Dhanapal Quarters)",
      "role": "Primary Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "A-",
      "phone": "+91 96871 51873",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Headmaster Dhanapal Quarters in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -3.66,
        0.5,
        -9.22
      ]
    },
    {
      "id": 135,
      "name": "Saravanan Varma",
      "age": 53,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-302 (Panchayat President Residence)",
      "role": "Resident",
      "occupation": "School Teacher",
      "bloodGroup": "A-",
      "phone": "+91 96260 49035",
      "skills": "School Teacher • Village Community Member",
      "bio": "Active resident of Panchayat President Residence in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -4.66,
        0.5,
        -5.97
      ]
    },
    {
      "id": 136,
      "name": "Sumathi Patil",
      "age": 19,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-303 (Village Post & Tele Center House)",
      "role": "College Youth / SHG Volunteer",
      "occupation": "College Student",
      "bloodGroup": "A-",
      "phone": "+91 99566 17000",
      "skills": "College Student • Village Community Member",
      "bio": "Active resident of Village Post & Tele Center House in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        0.64,
        0.5,
        -7.43
      ]
    },
    {
      "id": 137,
      "name": "Gopal Nayakar",
      "age": 6,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-304 (VHN Health Worker Quarters)",
      "role": "Primary Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "A+",
      "phone": "+91 95801 38155",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of VHN Health Worker Quarters in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        3.44,
        0.5,
        -9.68
      ]
    },
    {
      "id": 138,
      "name": "Devi Kounder",
      "age": 30,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-305 (Chai & Grocery Corner Residence)",
      "role": "Resident",
      "occupation": "Horticulturist (Mango & Coconut)",
      "bloodGroup": "A+",
      "phone": "+91 99908 41844",
      "skills": "Horticulturist (Mango & Coconut) • Village Community Member",
      "bio": "Active resident of Chai & Grocery Corner Residence in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -6.35,
        0.5,
        -11.28
      ]
    },
    {
      "id": 139,
      "name": "Rajesh Reddy",
      "age": 64,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-306 (Senthil Tailoring House)",
      "role": "Village Elder & Mentor",
      "occupation": "Temple & Heritage Advisor",
      "bloodGroup": "B-",
      "phone": "+91 91207 75933",
      "skills": "Temple & Heritage Advisor • Village Community Member",
      "bio": "Active resident of Senthil Tailoring House in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -1.6,
        0.5,
        -13.37
      ]
    },
    {
      "id": 140,
      "name": "Shanthi Gounder",
      "age": 32,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-307 (Logu Electrical Works House)",
      "role": "Resident",
      "occupation": "Retired Postal Officer",
      "bloodGroup": "A-",
      "phone": "+91 95995 69005",
      "skills": "Retired Postal Officer • Village Community Member",
      "bio": "Active resident of Logu Electrical Works House in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        3.45,
        0.5,
        -14
      ]
    },
    {
      "id": 141,
      "name": "Venkatesh Naidu",
      "age": 15,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-308 (Kannan Teacher Cottage)",
      "role": "High School Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "O-",
      "phone": "+91 98260 44938",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Kannan Teacher Cottage in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -8.51,
        0.5,
        -15.69
      ]
    },
    {
      "id": 142,
      "name": "Vijaya Pillai",
      "age": 58,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-309 (Anganwadi Supervisor Residence)",
      "role": "Resident",
      "occupation": "Temple Priest / Archagar",
      "bloodGroup": "O+",
      "phone": "+91 94991 94744",
      "skills": "Temple Priest / Archagar • Village Community Member",
      "bio": "Active resident of Anganwadi Supervisor Residence in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        5.27,
        0.5,
        -8.13
      ]
    },
    {
      "id": 143,
      "name": "Anbu Thevar",
      "age": 52,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-310 (Co-op Dairy Secretary Home)",
      "role": "Resident",
      "occupation": "Gram Panchayat Member",
      "bloodGroup": "AB+",
      "phone": "+91 97883 49429",
      "skills": "Gram Panchayat Member • Village Community Member",
      "bio": "Active resident of Co-op Dairy Secretary Home in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -3.59,
        0.5,
        -17.89
      ]
    },
    {
      "id": 144,
      "name": "Gomathi Mudaliar",
      "age": 37,
      "gender": "Female",
      "wardId": 4,
      "houseNo": "H-401 (Perumal Heritage Home)",
      "role": "Resident",
      "occupation": "Horticulturist (Mango & Coconut)",
      "bloodGroup": "B+",
      "phone": "+91 96626 95337",
      "skills": "Horticulturist (Mango & Coconut) • Village Community Member",
      "bio": "Active resident of Perumal Heritage Home in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -40.05,
        0.5,
        -11.56
      ]
    },
    {
      "id": 145,
      "name": "Senthil Achari",
      "age": 21,
      "gender": "Male",
      "wardId": 4,
      "houseNo": "H-402 (Chinnathambi Homestead)",
      "role": "Youth Brigade Member",
      "occupation": "Young Agripreneur",
      "bloodGroup": "B-",
      "phone": "+91 98885 68592",
      "skills": "Young Agripreneur • Village Community Member",
      "bio": "Active resident of Chinnathambi Homestead in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -43.73,
        0.5,
        -14.35
      ]
    },
    {
      "id": 146,
      "name": "Saradha Yadav",
      "age": 23,
      "gender": "Female",
      "wardId": 4,
      "houseNo": "H-403 (Velu Potter & Artisan House)",
      "role": "College Youth / SHG Volunteer",
      "occupation": "Horticulturist (Mango & Coconut)",
      "bloodGroup": "A-",
      "phone": "+91 92525 31072",
      "skills": "Horticulturist (Mango & Coconut) • Village Community Member",
      "bio": "Active resident of Velu Potter & Artisan House in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -37.57,
        0.5,
        -16.34
      ]
    },
    {
      "id": 147,
      "name": "Praveen Chettiar",
      "age": 68,
      "gender": "Male",
      "wardId": 4,
      "houseNo": "H-404 (Rajesh Youth Sports House)",
      "role": "Village Elder & Mentor",
      "occupation": "Temple & Heritage Advisor",
      "bloodGroup": "B+",
      "phone": "+91 95710 73827",
      "skills": "Temple & Heritage Advisor • Village Community Member",
      "bio": "Active resident of Rajesh Youth Sports House in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -46.53,
        0.5,
        -9.51
      ]
    },
    {
      "id": 148,
      "name": "Malathi Gowda",
      "age": 19,
      "gender": "Female",
      "wardId": 4,
      "houseNo": "H-405 (Palani Weaver House)",
      "role": "College Youth / SHG Volunteer",
      "occupation": "Organic Farmer",
      "bloodGroup": "B-",
      "phone": "+91 97861 71103",
      "skills": "Organic Farmer • Village Community Member",
      "bio": "Active resident of Palani Weaver House in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -35.67,
        0.5,
        -10.73
      ]
    },
    {
      "id": 149,
      "name": "Dinesh Nadar",
      "age": 58,
      "gender": "Male",
      "wardId": 4,
      "houseNo": "H-406 (Ganesan Farmer Villa)",
      "role": "Resident",
      "occupation": "Gram Panchayat Member",
      "bloodGroup": "O+",
      "phone": "+91 99872 61158",
      "skills": "Gram Panchayat Member • Village Community Member",
      "bio": "Active resident of Ganesan Farmer Villa in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -43.74,
        0.5,
        -20.62
      ]
    },
    {
      "id": 150,
      "name": "Karpagam Iyer",
      "age": 76,
      "gender": "Female",
      "wardId": 4,
      "houseNo": "H-407 (Ayyappan Cattle Shed Home)",
      "role": "Village Elder & Mentor",
      "occupation": "Retired Farmer / Elder",
      "bloodGroup": "O+",
      "phone": "+91 98047 10235",
      "skills": "Retired Farmer / Elder • Village Community Member",
      "bio": "Active resident of Ayyappan Cattle Shed Home in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -48.55,
        0.5,
        -16.32
      ]
    },
    {
      "id": 151,
      "name": "Chandran Varma",
      "age": 14,
      "gender": "Male",
      "wardId": 4,
      "houseNo": "H-408 (Dharmalingam Agro House)",
      "role": "High School Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "A+",
      "phone": "+91 92303 78642",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Dharmalingam Agro House in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -34.57,
        0.5,
        -19.73
      ]
    },
    {
      "id": 152,
      "name": "Mallika Patil",
      "age": 44,
      "gender": "Female",
      "wardId": 4,
      "houseNo": "H-409 (Madhavan Green Field Cottage)",
      "role": "Resident",
      "occupation": "College Student (B.Tech)",
      "bloodGroup": "O+",
      "phone": "+91 90137 65284",
      "skills": "College Student (B.Tech) • Village Community Member",
      "bio": "Active resident of Madhavan Green Field Cottage in Ward 4: West Agricultural Colony. Participates in village assemblies and festive events.",
      "coordinates": [
        -50.59,
        0.5,
        -12.71
      ]
    },
    {
      "id": 153,
      "name": "Sundaram Nayakar",
      "age": 67,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-101 (Temple Archagar Residence)",
      "role": "Village Elder & Mentor",
      "occupation": "Retired Farmer / Elder",
      "bloodGroup": "A+",
      "phone": "+91 96015 24604",
      "skills": "Retired Farmer / Elder • Village Community Member",
      "bio": "Active resident of Temple Archagar Residence in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -18.04,
        0.5,
        14.24
      ]
    },
    {
      "id": 154,
      "name": "Renuka Kounder",
      "age": 15,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-102 (Muthu Gounder Farmhouse)",
      "role": "High School Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "A+",
      "phone": "+91 92317 62746",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Muthu Gounder Farmhouse in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -21.91,
        0.5,
        15.39
      ]
    },
    {
      "id": 155,
      "name": "Muthu Reddy",
      "age": 78,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-103 (Karpagam Illam)",
      "role": "Village Elder & Mentor",
      "occupation": "Retired Farmer / Elder",
      "bloodGroup": "A-",
      "phone": "+91 96491 76876",
      "skills": "Retired Farmer / Elder • Village Community Member",
      "bio": "Active resident of Karpagam Illam in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -25.3,
        0.5,
        11.91
      ]
    },
    {
      "id": 156,
      "name": "Nandhini Gounder",
      "age": 20,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-104 (Sri Ganesh Krupa)",
      "role": "College Youth / SHG Volunteer",
      "occupation": "College Student",
      "bloodGroup": "B+",
      "phone": "+91 92172 17827",
      "skills": "College Student • Village Community Member",
      "bio": "Active resident of Sri Ganesh Krupa in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -20.54,
        0.5,
        7.91
      ]
    },
    {
      "id": 157,
      "name": "Arun Naidu",
      "age": 82,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-105 (Anbu Dairy Farm)",
      "role": "Village Elder & Mentor",
      "occupation": "Retired Farmer / Elder",
      "bloodGroup": "B-",
      "phone": "+91 92542 81237",
      "skills": "Retired Farmer / Elder • Village Community Member",
      "bio": "Active resident of Anbu Dairy Farm in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -15.39,
        0.5,
        7.34
      ]
    },
    {
      "id": 158,
      "name": "Sindhu Pillai",
      "age": 22,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-106 (Shiva Lingam Residence)",
      "role": "College Youth / SHG Volunteer",
      "occupation": "Electrical Technician",
      "bloodGroup": "O-",
      "phone": "+91 95752 32174",
      "skills": "Electrical Technician • Village Community Member",
      "bio": "Active resident of Shiva Lingam Residence in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -12.67,
        0.5,
        12.18
      ]
    },
    {
      "id": 159,
      "name": "Vijay Thevar",
      "age": 22,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-107 (Devi Nilayam)",
      "role": "Youth Brigade Member",
      "occupation": "College Student",
      "bloodGroup": "A+",
      "phone": "+91 94736 36269",
      "skills": "College Student • Village Community Member",
      "bio": "Active resident of Devi Nilayam in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -14.69,
        0.5,
        17.73
      ]
    },
    {
      "id": 160,
      "name": "Poornima Mudaliar",
      "age": 43,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-108 (Saravanan Store House)",
      "role": "Resident",
      "occupation": "Mason & Builder",
      "bloodGroup": "AB+",
      "phone": "+91 94664 23442",
      "skills": "Mason & Builder • Village Community Member",
      "bio": "Active resident of Saravanan Store House in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -17.4,
        0.5,
        20.57
      ]
    },
    {
      "id": 161,
      "name": "Kannan Achari",
      "age": 23,
      "gender": "Male",
      "wardId": 1,
      "houseNo": "H-109 (Venkatesh Agro Quarters)",
      "role": "Youth Brigade Member",
      "occupation": "Horticulturist (Mango & Coconut)",
      "bloodGroup": "O-",
      "phone": "+91 93096 62203",
      "skills": "Horticulturist (Mango & Coconut) • Village Community Member",
      "bio": "Active resident of Venkatesh Agro Quarters in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -23.95,
        0.5,
        19.98
      ]
    },
    {
      "id": 162,
      "name": "Subhashini Yadav",
      "age": 49,
      "gender": "Female",
      "wardId": 1,
      "houseNo": "H-110 (Marimuthu Cottage)",
      "role": "Resident",
      "occupation": "Electrical Technician",
      "bloodGroup": "O+",
      "phone": "+91 92402 94525",
      "skills": "Electrical Technician • Village Community Member",
      "bio": "Active resident of Marimuthu Cottage in Ward 1: Hanuman Temple Street. Participates in village assemblies and festive events.",
      "coordinates": [
        -28.1,
        0.5,
        15.55
      ]
    },
    {
      "id": 163,
      "name": "Shankar Chettiar",
      "age": 24,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-201 (Thiru Youth Leader Illam)",
      "role": "Youth Brigade Member",
      "occupation": "Young Agripreneur",
      "bloodGroup": "O+",
      "phone": "+91 90204 64224",
      "skills": "Young Agripreneur • Village Community Member",
      "bio": "Active resident of Thiru Youth Leader Illam in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        14.35,
        0.5,
        23.59
      ]
    },
    {
      "id": 164,
      "name": "Kokila Gowda",
      "age": 28,
      "gender": "Female",
      "wardId": 2,
      "houseNo": "H-202 (Arun Youth Brigade Quarters)",
      "role": "College Youth / SHG Volunteer",
      "occupation": "Auto & Tractor Driver",
      "bloodGroup": "B+",
      "phone": "+91 95160 76221",
      "skills": "Auto & Tractor Driver • Village Community Member",
      "bio": "Active resident of Arun Youth Brigade Quarters in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        18.86,
        0.5,
        26.71
      ]
    },
    {
      "id": 165,
      "name": "Pandian Nadar",
      "age": 53,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-203 (Selvam Organic Orchard)",
      "role": "Resident",
      "occupation": "Dairy Farm Owner",
      "bloodGroup": "A-",
      "phone": "+91 93818 92093",
      "skills": "Dairy Farm Owner • Village Community Member",
      "bio": "Active resident of Selvam Organic Orchard in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        21.57,
        0.5,
        21.71
      ]
    },
    {
      "id": 166,
      "name": "Yamuna Iyer",
      "age": 20,
      "gender": "Female",
      "wardId": 2,
      "houseNo": "H-204 (Karthik Dairy Homestead)",
      "role": "College Youth / SHG Volunteer",
      "occupation": "Young Agripreneur",
      "bloodGroup": "B-",
      "phone": "+91 97548 79664",
      "skills": "Young Agripreneur • Village Community Member",
      "bio": "Active resident of Karthik Dairy Homestead in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        12.95,
        0.5,
        27.49
      ]
    },
    {
      "id": 167,
      "name": "Velu Varma",
      "age": 19,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-205 (Subramani Farmstead)",
      "role": "Youth Brigade Member",
      "occupation": "College Student",
      "bloodGroup": "O+",
      "phone": "+91 91388 74014",
      "skills": "College Student • Village Community Member",
      "bio": "Active resident of Subramani Farmstead in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        24.76,
        0.5,
        24.46
      ]
    },
    {
      "id": 168,
      "name": "Selvi Patil",
      "age": 57,
      "gender": "Female",
      "wardId": 2,
      "houseNo": "H-206 (Praveen Agro Green)",
      "role": "Resident",
      "occupation": "Youth Club Coordinator",
      "bloodGroup": "O-",
      "phone": "+91 94625 28562",
      "skills": "Youth Club Coordinator • Village Community Member",
      "bio": "Active resident of Praveen Agro Green in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        11,
        0.5,
        19.95
      ]
    },
    {
      "id": 169,
      "name": "Natarajan Nayakar",
      "age": 61,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-207 (Sundaram Coconut Grove)",
      "role": "Village Elder & Mentor",
      "occupation": "Temple & Heritage Advisor",
      "bloodGroup": "O-",
      "phone": "+91 93448 27260",
      "skills": "Temple & Heritage Advisor • Village Community Member",
      "bio": "Active resident of Sundaram Coconut Grove in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        19.92,
        0.5,
        18.46
      ]
    },
    {
      "id": 170,
      "name": "Bharathi Kounder",
      "age": 14,
      "gender": "Female",
      "wardId": 2,
      "houseNo": "H-208 (Vijay Modern Farm)",
      "role": "High School Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "A+",
      "phone": "+91 97606 98811",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Vijay Modern Farm in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        26.84,
        0.5,
        27.3
      ]
    },
    {
      "id": 171,
      "name": "Dhanapal Reddy",
      "age": 29,
      "gender": "Male",
      "wardId": 2,
      "houseNo": "H-209 (Balu Cattle Ranch)",
      "role": "Resident",
      "occupation": "Village Artisan / Carpenter",
      "bloodGroup": "B-",
      "phone": "+91 92129 80953",
      "skills": "Village Artisan / Carpenter • Village Community Member",
      "bio": "Active resident of Balu Cattle Ranch in Ward 2: Thiru Garden & East Hamlet. Participates in village assemblies and festive events.",
      "coordinates": [
        15.46,
        0.5,
        31.23
      ]
    },
    {
      "id": 172,
      "name": "Abirami Gounder",
      "age": 58,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-301 (Headmaster Dhanapal Quarters)",
      "role": "Resident",
      "occupation": "Mason & Builder",
      "bloodGroup": "B+",
      "phone": "+91 91188 47162",
      "skills": "Mason & Builder • Village Community Member",
      "bio": "Active resident of Headmaster Dhanapal Quarters in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -2.61,
        0.5,
        -8.88
      ]
    },
    {
      "id": 173,
      "name": "Raghavan Naidu",
      "age": 45,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-302 (Panchayat President Residence)",
      "role": "Resident",
      "occupation": "High School Student",
      "bloodGroup": "O+",
      "phone": "+91 95949 59339",
      "skills": "High School Student • Village Community Member",
      "bio": "Active resident of Panchayat President Residence in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -4.37,
        0.5,
        -6.2
      ]
    },
    {
      "id": 174,
      "name": "Padma Pillai",
      "age": 55,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-303 (Village Post & Tele Center House)",
      "role": "Resident",
      "occupation": "Village Artisan / Carpenter",
      "bloodGroup": "AB+",
      "phone": "+91 95632 39958",
      "skills": "Village Artisan / Carpenter • Village Community Member",
      "bio": "Active resident of Village Post & Tele Center House in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        0.44,
        0.5,
        -7.24
      ]
    },
    {
      "id": 175,
      "name": "Subramani Thevar",
      "age": 35,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-304 (VHN Health Worker Quarters)",
      "role": "Resident",
      "occupation": "Organic Farmer",
      "bloodGroup": "A-",
      "phone": "+91 96065 99133",
      "skills": "Organic Farmer • Village Community Member",
      "bio": "Active resident of VHN Health Worker Quarters in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        4.39,
        0.5,
        -10.51
      ]
    },
    {
      "id": 176,
      "name": "Uma Mudaliar",
      "age": 17,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-305 (Chai & Grocery Corner Residence)",
      "role": "High School Student",
      "occupation": "Student (GBG Village School)",
      "bloodGroup": "B-",
      "phone": "+91 96085 77035",
      "skills": "Student (GBG Village School) • Village Community Member",
      "bio": "Active resident of Chai & Grocery Corner Residence in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -7.07,
        0.5,
        -11.35
      ]
    },
    {
      "id": 177,
      "name": "Ravi Achari",
      "age": 67,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-306 (Senthil Tailoring House)",
      "role": "Village Elder & Mentor",
      "occupation": "Retired Farmer / Elder",
      "bloodGroup": "O-",
      "phone": "+91 92475 10942",
      "skills": "Retired Farmer / Elder • Village Community Member",
      "bio": "Active resident of Senthil Tailoring House in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -1.29,
        0.5,
        -12.55
      ]
    },
    {
      "id": 178,
      "name": "Lalitha Yadav",
      "age": 67,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-307 (Logu Electrical Works House)",
      "role": "Village Elder & Mentor",
      "occupation": "Temple & Heritage Advisor",
      "bloodGroup": "A+",
      "phone": "+91 96133 87265",
      "skills": "Temple & Heritage Advisor • Village Community Member",
      "bio": "Active resident of Logu Electrical Works House in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        2.26,
        0.5,
        -13.92
      ]
    },
    {
      "id": 179,
      "name": "Kumaran Chettiar",
      "age": 65,
      "gender": "Male",
      "wardId": 3,
      "houseNo": "H-308 (Kannan Teacher Cottage)",
      "role": "Village Elder & Mentor",
      "occupation": "Retired Farmer / Elder",
      "bloodGroup": "B+",
      "phone": "+91 90565 19226",
      "skills": "Retired Farmer / Elder • Village Community Member",
      "bio": "Active resident of Kannan Teacher Cottage in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        -8.43,
        0.5,
        -15.15
      ]
    },
    {
      "id": 180,
      "name": "Chitra Gowda",
      "age": 55,
      "gender": "Female",
      "wardId": 3,
      "houseNo": "H-309 (Anganwadi Supervisor Residence)",
      "role": "Resident",
      "occupation": "College Student (Agri)",
      "bloodGroup": "A+",
      "phone": "+91 99575 99925",
      "skills": "College Student (Agri) • Village Community Member",
      "bio": "Active resident of Anganwadi Supervisor Residence in Ward 3: School Road & Panchayat Center. Participates in village assemblies and festive events.",
      "coordinates": [
        6.44,
        0.5,
        -7.81
      ]
    }
  ]
};

if (typeof window !== "undefined") { window.VILLAGE_DATA = VILLAGE_DATA; }
if (typeof module !== "undefined") { module.exports = VILLAGE_DATA; }
