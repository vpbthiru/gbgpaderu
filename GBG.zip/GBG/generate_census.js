// Generator script for 180 Authentic Village Residents of Gangavaram / GBG Village
const fs = require('fs');

const occupations = [
  'Organic Farmer', 'Paddy Cultivator', 'Dairy Farm Owner', 'School Teacher',
  'Gram Panchayat Member', 'Anganwadi Worker', 'College Student (B.Tech)', 'College Student (Agri)',
  'High School Student', 'Temple Priest / Archagar', 'Village Artisan / Carpenter',
  'Mason & Builder', 'Grocery Store Merchant', 'Electrical Technician', 'Primary Health Nurse (VHN)',
  'Auto & Tractor Driver', 'Tailoring & Garment Unit Leader', 'Retired Postal Officer',
  'Horticulturist (Mango & Coconut)', 'Youth Club Coordinator', 'Cattle Care Specialist',
  'Self-Help Group (SHG) Leader', 'Civil Engineering Apprentice', 'Village Musician & Drummer'
];

const bloodGroups = ['O+', 'A+', 'B+', 'AB+', 'O-', 'A-', 'B-'];

const wards = [
  { id: 1, name: 'Ward 1: Hanuman Temple Street', center: [-18, 0, 12], houses: 10, prefix: 'W1' },
  { id: 2, name: 'Ward 2: Thiru Garden & East Hamlet', center: [16, 0, 24], houses: 9, prefix: 'W2' },
  { id: 3, name: 'Ward 3: School Road & Panchayat Center', center: [-2, 0, -8], houses: 10, prefix: 'W3' },
  { id: 4, name: 'Ward 4: West Agricultural Colony', center: [-42, 0, -14], houses: 9, prefix: 'W4' }
];

const maleFirstNames = [
  'Thiru', 'Selvam', 'Murugan', 'Karthik', 'Balu', 'Ramesh', 'Suresh', 'Manikandan',
  'Saravanan', 'Gopal', 'Rajesh', 'Venkatesh', 'Anbu', 'Senthil', 'Praveen', 'Dinesh',
  'Chandran', 'Sundaram', 'Muthu', 'Arun', 'Vijay', 'Kannan', 'Shankar', 'Pandian',
  'Velu', 'Natarajan', 'Dhanapal', 'Raghavan', 'Subramani', 'Ravi', 'Kumaran', 'Loganathan',
  'Shiva', 'Govind', 'Ramu', 'Somu', 'Elango', 'Madhavan', 'Aravind', 'Harish',
  'Vasanth', 'Vignesh', 'Prabhu', 'Balamurugan', 'Krishnan', 'Ramachandran', 'Ganesan',
  'Mani', 'Perumal', 'Marimuthu', 'Palani', 'Chinnathambi', 'Ayyappan', 'Dharmalingam'
];

const femaleFirstNames = [
  'Lakshmi', 'Parvathi', 'Meena', 'Anitha', 'Kavitha', 'Geetha', 'Radha', 'Sangeetha',
  'Revathi', 'Deepa', 'Priya', 'Sudha', 'Bhavani', 'Vasanthi', 'Kamala', 'Sumathi',
  'Devi', 'Shanthi', 'Vijaya', 'Gomathi', 'Saradha', 'Malathi', 'Karpagam', 'Mallika',
  'Renuka', 'Nandhini', 'Sindhu', 'Poornima', 'Subhashini', 'Kokila', 'Yamuna', 'Selvi',
  'Bharathi', 'Abirami', 'Padma', 'Uma', 'Lalitha', 'Chitra', 'Swathi', 'Divya',
  'Kasturi', 'Menaka', 'Padmini', 'Alamelu', 'Kalyani', 'Sujatha', 'Mohana', 'Rajalakshmi'
];

const surNames = [
  'Kounder', 'Reddy', 'Gounder', 'Naidu', 'Pillai', 'Thevar', 'Mudaliar', 'Achari',
  'Yadav', 'Chettiar', 'Gowda', 'Nadar', 'Iyer', 'Varma', 'Patil', 'Nayakar'
];

// Special profiles for key village pillars
const keyProfiles = [
  {
    id: 1,
    name: 'Thiru (Thirumalai R.)',
    age: 27,
    gender: 'Male',
    wardId: 2,
    houseNo: 'H-201 (Thiru Illam)',
    role: 'Village Youth Leader & Social Pioneer',
    occupation: 'Agripreneur & Youth President',
    bloodGroup: 'O+',
    phone: '+91 98421 77201',
    skills: 'Youth Welfare, Solar Street Lighting Project, Drinking Water RO Plants, Hanuman Sports Festival Organiser',
    bio: 'Dynamic youth leader driving modern education, sports tournaments, solar energy and tree plantation drives across GBG village.',
    coordinates: [15, 0.5, 23],
    isHero: true,
    photoBadge: '⭐ YOUTH LEADER'
  },
  {
    id: 2,
    name: 'Ramaswamy Kounder',
    age: 58,
    gender: 'Male',
    wardId: 2,
    houseNo: 'H-201 (Thiru Illam)',
    role: "Father of Thiru / Senior Farmer",
    occupation: 'Traditional Paddy & Sugarcane Farmer',
    bloodGroup: 'B+',
    phone: '+91 94432 11202',
    skills: 'Organic water conservation, cattle breeding',
    bio: 'Respected farming patriarch in the village. Father of Youth Leader Thiru.',
    coordinates: [15, 0.5, 23]
  },
  {
    id: 3,
    name: 'Kalyani Ramaswamy',
    age: 52,
    gender: 'Female',
    wardId: 2,
    houseNo: 'H-201 (Thiru Illam)',
    role: "Mother of Thiru / SHG Leader",
    occupation: 'Dairy Management & SHG Treasurer',
    bloodGroup: 'O+',
    phone: '+91 94432 11203',
    skills: 'Women Self Help Group mentor, traditional herbal remedies',
    bio: 'Community matriarch who heads the Sri Lakshmi Women Self Help Group.',
    coordinates: [15, 0.5, 23]
  },
  {
    id: 4,
    name: 'Deepa Ramaswamy',
    age: 23,
    gender: 'Female',
    wardId: 2,
    houseNo: 'H-201 (Thiru Illam)',
    role: "Sister of Thiru",
    occupation: 'M.Sc. Agriculture Graduate & Educator',
    bloodGroup: 'A+',
    phone: '+91 98421 77204',
    skills: 'Soil health analysis, digital literacy for school children',
    bio: 'Conducts evening digital classes for village students alongside Thiru.',
    coordinates: [15, 0.5, 23]
  },
  {
    id: 5,
    name: 'Pandian Archagar',
    age: 64,
    gender: 'Male',
    wardId: 1,
    houseNo: 'H-101 (Temple Archagar Residence)',
    role: 'Head Priest (Sri Hanuman Temple)',
    occupation: 'Vedic Scholar & Temple Archagar',
    bloodGroup: 'A+',
    phone: '+91 94420 88101',
    skills: 'Vedic rituals, Hanuman Jayanti grand celebration head, community blessings',
    bio: 'Serving the village Hanuman Temple for over 40 years with devotional hymns and festival leadership.',
    coordinates: [-18, 0.5, 14]
  },
  {
    id: 6,
    name: 'Meenakshi Pandian',
    age: 59,
    gender: 'Female',
    wardId: 1,
    houseNo: 'H-101 (Temple Archagar Residence)',
    role: 'Temple Committee Member',
    occupation: 'Devotional Singer & Garland Artisan',
    bloodGroup: 'O+',
    phone: '+91 94420 88102',
    skills: 'Floral decorations for deities, devotional music',
    bio: 'Coordinates the daily floral offerings and prasadam for Hanuman Temple visitors.',
    coordinates: [-18, 0.5, 14]
  },
  {
    id: 7,
    name: 'Master Dhanapal M.A., B.Ed.',
    age: 51,
    gender: 'Male',
    wardId: 3,
    houseNo: 'H-301 (School Master Quarters)',
    role: 'Headmaster (Govt. Village School)',
    occupation: 'Headmaster & Science Educator',
    bloodGroup: 'B+',
    phone: '+91 94883 44301',
    skills: 'Science education, 100% pass rate mentor, national science club guide',
    bio: 'Under his leadership, GBG Village School won the Taluk Best Rural School Award in 2024.',
    coordinates: [-3, 0.5, -9]
  },
  {
    id: 8,
    name: 'Radha Dhanapal',
    age: 46,
    gender: 'Female',
    wardId: 3,
    houseNo: 'H-301 (School Master Quarters)',
    role: 'Senior Primary Teacher',
    occupation: 'Mathematics & Tamil Teacher',
    bloodGroup: 'A+',
    phone: '+91 94883 44302',
    skills: 'Vedic mathematics, drama and arts coaching',
    bio: 'Nurturing generations of village children with fond warmth and educational discipline.',
    coordinates: [-3, 0.5, -9]
  },
  {
    id: 9,
    name: 'Natarajan Gowda',
    age: 62,
    gender: 'Male',
    wardId: 3,
    houseNo: 'H-302 (Panchayat Bhavan Road)',
    role: 'Gram Panchayat President',
    occupation: 'Civic Administration & Senior Planter',
    bloodGroup: 'AB+',
    phone: '+91 94431 55301',
    skills: 'Village infrastructure schemes, road connectivity, dispute resolution',
    bio: 'Senior village elder working closely with Youth Leader Thiru to modernise village amenities.',
    coordinates: [-5, 0.5, -6]
  }
];

// Generate 180 total authentic persons
const persons = [...keyProfiles];

let currentId = keyProfiles.length + 1;

// Define 38 houses across the 4 wards
const houseData = [
  // Ward 1 (Temple area)
  { wardId: 1, houseNo: 'H-101', name: 'Temple Archagar Residence', x: -18, z: 14, residents: [5, 6] },
  { wardId: 1, houseNo: 'H-102', name: 'Muthu Gounder Farmhouse', x: -22, z: 16, residents: [] },
  { wardId: 1, houseNo: 'H-103', name: 'Karpagam Illam', x: -25, z: 12, residents: [] },
  { wardId: 1, houseNo: 'H-104', name: 'Sri Ganesh Krupa', x: -20, z: 8, residents: [] },
  { wardId: 1, houseNo: 'H-105', name: 'Anbu Dairy Farm', x: -15, z: 8, residents: [] },
  { wardId: 1, houseNo: 'H-106', name: 'Shiva Lingam Residence', x: -12, z: 12, residents: [] },
  { wardId: 1, houseNo: 'H-107', name: 'Devi Nilayam', x: -14, z: 18, residents: [] },
  { wardId: 1, houseNo: 'H-108', name: 'Saravanan Store House', x: -18, z: 20, residents: [] },
  { wardId: 1, houseNo: 'H-109', name: 'Venkatesh Agro Quarters', x: -24, z: 20, residents: [] },
  { wardId: 1, houseNo: 'H-110', name: 'Marimuthu Cottage', x: -28, z: 15, residents: [] },

  // Ward 2 (Thiru's Estate & East Hamlet)
  { wardId: 2, houseNo: 'H-201', name: "Thiru Youth Leader Illam", x: 15, z: 23, residents: [1, 2, 3, 4] },
  { wardId: 2, houseNo: 'H-202', name: 'Arun Youth Brigade Quarters', x: 19, z: 26, residents: [] },
  { wardId: 2, houseNo: 'H-203', name: 'Selvam Organic Orchard', x: 22, z: 21, residents: [] },
  { wardId: 2, houseNo: 'H-204', name: 'Karthik Dairy Homestead', x: 13, z: 28, residents: [] },
  { wardId: 2, houseNo: 'H-205', name: 'Subramani Farmstead', x: 25, z: 24, residents: [] },
  { wardId: 2, houseNo: 'H-206', name: 'Praveen Agro Green', x: 11, z: 20, residents: [] },
  { wardId: 2, houseNo: 'H-207', name: 'Sundaram Coconut Grove', x: 20, z: 18, residents: [] },
  { wardId: 2, houseNo: 'H-208', name: 'Vijay Modern Farm', x: 27, z: 28, residents: [] },
  { wardId: 2, houseNo: 'H-209', name: 'Balu Cattle Ranch', x: 16, z: 31, residents: [] },

  // Ward 3 (School & Panchayat Center)
  { wardId: 3, houseNo: 'H-301', name: 'Headmaster Dhanapal Quarters', x: -3, z: -9, residents: [7, 8] },
  { wardId: 3, houseNo: 'H-302', name: 'Panchayat President Residence', x: -5, z: -6, residents: [9] },
  { wardId: 3, houseNo: 'H-303', name: 'Village Post & Tele Center House', x: 1, z: -7, residents: [] },
  { wardId: 3, houseNo: 'H-304', name: 'VHN Health Worker Quarters', x: 4, z: -10, residents: [] },
  { wardId: 3, houseNo: 'H-305', name: 'Chai & Grocery Corner Residence', x: -7, z: -11, residents: [] },
  { wardId: 3, houseNo: 'H-306', name: 'Senthil Tailoring House', x: -1, z: -13, residents: [] },
  { wardId: 3, houseNo: 'H-307', name: 'Logu Electrical Works House', x: 3, z: -14, residents: [] },
  { wardId: 3, houseNo: 'H-308', name: 'Kannan Teacher Cottage', x: -8, z: -15, residents: [] },
  { wardId: 3, houseNo: 'H-309', name: 'Anganwadi Supervisor Residence', x: 6, z: -8, residents: [] },
  { wardId: 3, houseNo: 'H-310', name: 'Co-op Dairy Secretary Home', x: -4, z: -18, residents: [] },

  // Ward 4 (West Village Colony)
  { wardId: 4, houseNo: 'H-401', name: 'Perumal Heritage Home', x: -40, z: -12, residents: [] },
  { wardId: 4, houseNo: 'H-402', name: 'Chinnathambi Homestead', x: -44, z: -15, residents: [] },
  { wardId: 4, houseNo: 'H-403', name: 'Velu Potter & Artisan House', x: -38, z: -17, residents: [] },
  { wardId: 4, houseNo: 'H-404', name: 'Rajesh Youth Sports House', x: -46, z: -10, residents: [] },
  { wardId: 4, houseNo: 'H-405', name: 'Palani Weaver House', x: -36, z: -11, residents: [] },
  { wardId: 4, houseNo: 'H-406', name: 'Ganesan Farmer Villa', x: -43, z: -20, residents: [] },
  { wardId: 4, houseNo: 'H-407', name: 'Ayyappan Cattle Shed Home', x: -48, z: -16, residents: [] },
  { wardId: 4, houseNo: 'H-408', name: 'Dharmalingam Agro House', x: -35, z: -19, residents: [] },
  { wardId: 4, houseNo: 'H-409', name: 'Madhavan Green Field Cottage', x: -50, z: -12, residents: [] }
];

let mIdx = 0;
let fIdx = 0;
let sIdx = 0;

// Fill in the rest of the residents until exactly 180
while (persons.length < 180) {
  const availableHouses = houseData.slice().sort((a, b) => a.residents.length - b.residents.length);
  const targetHouse = availableHouses[0];

  const isMale = (persons.length % 2 === 0);
  const firstName = isMale ? maleFirstNames[(mIdx++) % maleFirstNames.length] : femaleFirstNames[(fIdx++) % femaleFirstNames.length];
  const surname = surNames[(sIdx++) % surNames.length];
  const fullName = firstName + ' ' + surname;

  let age;
  const rand = Math.random();
  if (rand < 0.18) {
    age = Math.floor(6 + Math.random() * 12);
  } else if (rand < 0.58) {
    age = Math.floor(18 + Math.random() * 20);
  } else if (rand < 0.85) {
    age = Math.floor(38 + Math.random() * 21);
  } else {
    age = Math.floor(59 + Math.random() * 25);
  }

  let role = 'Resident';
  let occupation = occupations[Math.floor(Math.random() * occupations.length)];

  if (age < 18) {
    role = age <= 10 ? 'Primary Student' : 'High School Student';
    occupation = 'Student (GBG Village School)';
  } else if (age >= 18 && age <= 28) {
    role = isMale ? 'Youth Brigade Member' : 'College Youth / SHG Volunteer';
    if (Math.random() < 0.4) occupation = 'College Student';
    else if (Math.random() < 0.6) occupation = 'Young Agripreneur';
  } else if (age > 60) {
    role = 'Village Elder & Mentor';
    occupation = Math.random() < 0.5 ? 'Retired Farmer / Elder' : 'Temple & Heritage Advisor';
  }

  const blood = bloodGroups[Math.floor(Math.random() * bloodGroups.length)];
  const phone = '+91 ' + (90000 + Math.floor(Math.random() * 9999)) + ' ' + (10000 + Math.floor(Math.random() * 89999));

  const jitterX = (Math.random() - 0.5) * 1.5;
  const jitterZ = (Math.random() - 0.5) * 1.5;

  const currentHouseWard = wards.find(function(w) { return w.id === targetHouse.wardId; });

  const person = {
    id: currentId,
    name: fullName,
    age: age,
    gender: isMale ? 'Male' : 'Female',
    wardId: targetHouse.wardId,
    houseNo: targetHouse.houseNo + ' (' + targetHouse.name + ')',
    role: role,
    occupation: occupation,
    bloodGroup: blood,
    phone: phone,
    skills: occupation + ' • Village Community Member',
    bio: 'Active resident of ' + targetHouse.name + ' in ' + currentHouseWard.name + '. Participates in village assemblies and festive events.',
    coordinates: [Number((targetHouse.x + jitterX).toFixed(2)), 0.5, Number((targetHouse.z + jitterZ).toFixed(2))]
  };

  targetHouse.residents.push(currentId);
  persons.push(person);
  currentId++;
}

console.log('Total persons prepared:', persons.length);

const outputJS = 'const VILLAGE_DATA = ' + JSON.stringify({
  villageName: "GBG Grama Panchayat (Gangavaram)",
  district: "Rural Development Zone",
  state: "Tamil Nadu",
  coordinates: "12°38'15''N 78°22'40''E",
  totalPopulation: persons.length,
  totalHouseholds: houseData.length,
  youthLeader: {
    name: "Thiru (Thirumalai R.)",
    title: "Youth Leader & Rural Changemaker",
    age: 27,
    houseNo: "H-201 (Thiru Illam)",
    tagline: "Empowering Rural Youth • Modern Agriculture • Traditional Values",
    bio: "Thiru is the beloved youth leader of GBG Village. Over the last 5 years, he has led the 100% solar lighting transition for village streets, established the clean drinking water RO kiosk, championed the annual Sri Hanuman Sports & Kabaddi Trophy, and launched digital learning classes for rural school students.",
    achievements: [
      { year: "2024", title: "Smart Solar Street Lights", desc: "Installed 48 LED solar street lights connecting Hanuman temple, school and residential wards." },
      { year: "2024", title: "Youth Digital Library", desc: "Created 10-computer digital literacy and study room for students at the Community Center." },
      { year: "2023", title: "Hanuman Youth Kabaddi Cup", desc: "Annual district-level tournament attracting 24 village teams with huge community participation." },
      { year: "2022", title: "Clean Water Mission", desc: "Constructed village RO drinking water kiosk ensuring 100% safe drinking water for all 180 residents." },
      { year: "2021", title: "Green Village Drive", desc: "Planted 500+ indigenous banyan, neem and fruit saplings along the main highway and farm paths." }
    ],
    contact: {
      phone: "+91 98421 77201",
      email: "thiru.youthgbg@gmail.com",
      office: "Youth Welfare Center, East Hamlet Road, GBG Village"
    },
    location: [15, 0.5, 23]
  },
  landmarks: [
    {
      id: "overview",
      name: "GBG Village Overview",
      subtitle: "Full Village Bird's Eye View",
      icon: "🌐",
      category: "Overview",
      cameraPos: [0, 85, 95],
      lookAt: [-5, 0, 5],
      description: "Aerial perspective of GBG Village showing the diagonal main transport road, lush terraced farm plots, the Hanuman Temple, School campus, and Thiru's residential sector."
    },
    {
      id: "temple",
      name: "Sri Hanuman Temple (ஆஞ்சநேயர் கோயில்)",
      subtitle: "Historic Village Shrine & Cultural Anchor",
      icon: "🕉️",
      category: "Religious & Heritage",
      cameraPos: [-18, 12, 28],
      lookAt: [-18, 2, 14],
      description: "The spiritual heart of GBG Village. Featuring a sculpted sanctum, golden pinnacle Kalash, sacred peepal tree chabutra, and fluttering saffron dhwaja. Hosts the grand annual Hanuman Jayanti and village harvest festival.",
      head: "Pandian Archagar (Senior Priest)",
      timing: "5:30 AM - 12:30 PM & 4:30 PM - 8:30 PM",
      features: ["Sacred Banyan Tree", "Mandapam Bell", "Daily Aarti Lamps", "Festival Grounds"]
    },
    {
      id: "thiru_house",
      name: "Youth Leader Thiru's Residence",
      subtitle: "Center for Youth Welfare & Agriculture Excellence",
      icon: "⭐",
      category: "Youth Leadership Hub",
      cameraPos: [15, 14, 38],
      lookAt: [15, 2, 23],
      description: "The residence of Youth Leader Thiru and the Ramaswamy family. A modern rural farmhouse featuring a solar rooftop, lush farm compound, tractor bay, and open youth meeting veranda where daily community programs are planned.",
      head: "Thiru (Youth President) & Family",
      activities: ["Youth Assembly & Sports Briefings", "Farmer Seed Distribution", "Solar Helpdesk", "24/7 Community Support"],
      features: ["Solar Rooftop Array", "Community Veranda", "Tractor & Agro Unit", "Garden Groves"]
    },
    {
      id: "school",
      name: "Govt. Village Primary & High School",
      subtitle: "Centre for Academic Excellence & Sports",
      icon: "🏫",
      category: "Education",
      cameraPos: [-3, 14, 8],
      lookAt: [-3, 2, -9],
      description: "L-shaped village school campus educating over 65 students from GBG and neighboring hamlets. Features an open assembly playground, Indian National Tricolor flag mast, digital smart lab, and kabaddi arena.",
      head: "Master Dhanapal M.A., B.Ed. (Headmaster)",
      features: ["National Flag Mast", "Digital Smart Classroom", "Sports Playground", "Free Mid-day Meal Kitchen"]
    },
    {
      id: "panchayat",
      name: "Gram Panchayat & Community Hall",
      subtitle: "Village Governance & Public Services",
      icon: "🏛️",
      category: "Administration",
      cameraPos: [-5, 14, 10],
      lookAt: [-5, 2, -6],
      description: "The administrative hub housing the Panchayat Office, E-Seva civic center, cooperative milk collection center, and overhead village water distribution tank.",
      head: "Natarajan Gowda (Panchayat President)",
      features: ["Overhead Water Tower", "Village Dairy Collection", "E-Seva Center", "Community Assembly Hall"]
    },
    {
      id: "west_cluster",
      name: "West Village Settlement (Ramaswamy Ward)",
      subtitle: "Heritage Village Residential Cluster",
      icon: "🏘️",
      category: "Residential Hamlet",
      cameraPos: [-42, 18, 4],
      lookAt: [-42, 2, -14],
      description: "Traditional residential heart of the village featuring 25+ tile-roofed brick homes, narrow shaded streets, ancestral courtyards, cattle sheds, and artisan workshops.",
      households: "18 Families",
      features: ["Clay-tiled Verandas", "Ancestral Courtyards", "Artisan Potter Workshops", "Cattle Byres"]
    },
    {
      id: "fields",
      name: "Green Agricultural Terraces & Groves",
      subtitle: "Lifeline of Village Economy",
      icon: "🌾",
      category: "Agriculture",
      cameraPos: [28, 25, 48],
      lookAt: [20, 0, 10],
      description: "Lush stepped farming terraces cultivating paddy, millets, sugarcane, coconut, and mango trees. Fed by borewells and traditional rainwater harvesting ponds.",
      features: ["Organic Paddy Fields", "Coconut Groves", "Drip Irrigation Units", "Canal Waterways"]
    }
  ],
  wards: wards,
  houses: houseData,
  persons: persons
}, null, 2) + ';\n\nif (typeof window !== "undefined") { window.VILLAGE_DATA = VILLAGE_DATA; }\nif (typeof module !== "undefined") { module.exports = VILLAGE_DATA; }\n';

fs.writeFileSync('c:/Users/ACER/Desktop/GBG/data.js', outputJS);
console.log('Successfully wrote clean data.js with JSON formatting!');
