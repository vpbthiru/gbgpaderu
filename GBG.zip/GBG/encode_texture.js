const fs = require('fs');
const imgBuffer = fs.readFileSync('satellite_map.jpg');
const base64 = imgBuffer.toString('base64');
const content = 'window.SATELLITE_BASE64 = "data:image/jpeg;base64,' + base64 + '";\n';
fs.writeFileSync('map_texture.js', content);
console.log('Created map_texture.js successfully! Length: ' + content.length);
