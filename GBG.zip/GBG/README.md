# 🌾 GBG Smart Village 3D Digital Twin & Community Census Portal

An interactive, photogrammetry-aligned 3D digital twin of **GBG Village (Gangavaram)**, featuring architectural 3D landmarks, pin-to-pin cinematic camera zooming, a dedicated hero showcase for beloved **Youth Leader Thiru**, and an interactive census of all **180 village residents** across 38 households.

---

## 🌟 Key Features

### 1. 🗺️ 3D Photogrammetry-Aligned Terrain & Buildings
- **Satellite Texture Mapping**: Aligned with the high-resolution aerial satellite image (`satellite_map.jpg`), with stepped agricultural elevation contours, farm pathways, and the main diagonal road.
- **Sri Hanuman Temple (ஆஞ்சநேயர் கோயில்)**:
  - Stone plinth, ornate mandapam pillars, stepped pyramidal *Vimana / Gopuram* tower.
  - Golden pinnacle *Kalash* finial.
  - Saffron *Hanuman Dhwaja* triangle flag animated with realistic wind flapping.
  - Hanging brass temple bell at entrance and inner sanctum with a warm flickering oil diya light.
  - Sacred Banyan/Peepal tree with circular stone *chabutra* seating.
- **Youth Leader Thiru's Residence (H-201)**:
  - Modeled precisely at the landmark pin visible in the satellite photo.
  - Two-story modern traditional farmhouse with terracotta hipped roof.
  - Rooftop solar photovoltaic panel arrays reflecting Thiru's 100% solar village initiative.
  - Front portico assembly veranda for youth meetings, parked farm tractor, coconut palms, and a floating pulsing golden crown indicator.
- **Govt. Primary & High School**:
  - L-shaped campus with classrooms, blue tiled roofs, and an open assembly playground.
  - Indian Tricolor flag mast with fluttering flag.
- **Panchayat Bhavan & Water Tower**:
  - Village administrative hall with overhead 4-pillar water reservoir tank tower.
- **38 Authentic Village Houses**:
  - Color-varied clay tile roofs, whitewashed/ochre walls, front verandas, and yards.
- **Lush Stepped Agricultural Fields**:
  - Terraced plots for organic paddy, millets, mustard, and sugarcane crops.

---

### 2. 📍 Pin-to-Pin Cinematic Zooming Engine
- Smooth cubic bezier ease-in-out camera trajectory smoothly swoops to any location:
  - 🌐 **Overview** (Full village bird's eye view)
  - 🕉️ **Sri Hanuman Temple** (Close-up of sanctum & mandapam)
  - ⭐ **Youth Leader Thiru's Residence** (Close-up of farmhouse, solar panels & tractor)
  - 🏫 **Govt. School** (Assembly grounds & classroom wing)
  - 🏛️ **Gram Panchayat & Water Tower**
  - 🏘️ **West Residential Hamlet** (Traditional clay tile homes)
  - 🌾 **Agricultural Terraces**
- Clicking any building or floating 3D pin opens the **Landmark Inspector Drawer** with history, leaders, features, and direct links to ward residents.
- **Automated Drone Tour**: Press the `▶` play button on the left toolbar to start a guided cinematic fly-through across all village highlights.

---

### 3. ⭐ Youth Leader Thiru — Hero Showcase
- Dedicated Hero Showcase section and profile modal highlighting **Thiru (Thirumalai R.)**:
  - **Title**: Village Youth Leader & Rural Changemaker (Age 27)
  - **Motto**: *"Modernizing our village with clean solar power, digital education, and flourishing agriculture, while keeping our sacred traditions alive."*
  - **Major Initiatives & Milestones**:
    1. **100% Smart Solar Street Lighting**: 48 LED solar lights installed.
    2. **Clean Drinking Water RO Plant**: Purified water for all 180 residents.
    3. **Annual Sri Hanuman Sports & Kabaddi Trophy**: District youth tournament.
    4. **Youth Digital Education Lab**: Free tuition & computer literacy.
    5. **500+ Indigenous Tree Plantation Drive**.
  - **Family Info**: Father Ramaswamy (Senior Farmer), Mother Kalyani (SHG President), Sister Deepa (Agri-Researcher).
  - **Instant Flyover Button**: "Fly to Thiru's House on 3D Map".

---

### 4. 👥 Complete 180-Resident Village Census & Directory
- Complete, culturally authentic database of all **180 residents** across 38 households:
  - **Fields**: ID, Full Name, Age, Gender, Role, Occupation, Ward, House No, Blood Group, Phone, Community bio.
  - **Instant Live Search**: Type any name, occupation, ward, or house number.
  - **Filter Chips**: All (180), Youth (18-35), Elders (60+), Farmers, Students, Leaders, Ward 1 to Ward 4.
  - **View Modes**: Switch between Grid Cards view and Sortable Data Table view.
  - **Locate on 3D Map Button**: Clicking any person's "Locate on 3D Map" button smoothly swoops the 3D camera right above their specific family home in the village!
  - **Export Data**: Download the complete 180 census as CSV or JSON with one click.

---

### 5. ☀️/🌙 Ambiance & Atmospheric Controls
- **Day / Golden Hour / Night Cycle**:
  - Day: Crisp sunlight and blue sky.
  - Sunset: Warm golden hour radiance and elongated shadows.
  - Night: Midnight sky, illuminated temple lamps, and glowing streetlights.
- **Procedural Soundscape**:
  - Built-in Web Audio API synthesizers for sacred temple bell chimes, school bell rings, and celebratory fanfare (zero external audio files needed).
- **Snapshot Camera**: Take high-resolution PNG captures of any 3D angle.

---

## 🚀 How to Run

### Method 1: Using the Built-in Server (Recommended)
1. Double-click `start_server.bat` in this folder, OR open PowerShell / Terminal and run:
   ```bash
   node server.js
   ```
2. Open your web browser at:
   ```
   http://localhost:3000
   ```

### Method 2: Direct Browser Launch
- Double-click `index.html` to open it in Chrome, Edge, or Firefox.
- Note: Thanks to the embedded base64 satellite texture in `map_texture.js`, all 3D textures, models, and census records load with 100% reliability offline or online!
